package phantom.modules.impl.combat;

import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;

public class SurroundModule extends Module {
    private final BooleanSetting center=addSetting(new BooleanSetting("Center",true));
    private static final Direction[] HORIZ={Direction.NORTH,Direction.SOUTH,Direction.EAST,Direction.WEST};
    public SurroundModule(){super("Surround","Places obsidian around your feet.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null||mc.world==null)return;
        if(center.isEnabled()) mc.player.setPosition(Math.floor(mc.player.getX())+0.5,mc.player.getY(),Math.floor(mc.player.getZ())+0.5);
        BlockPos feet=mc.player.getBlockPos();
        int obsSlot=findObsidian(); if(obsSlot==-1)return;
        int prev=mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot=obsSlot;
        for(Direction d:HORIZ){
            BlockPos target=feet.offset(d);
            if(!mc.world.getBlockState(target).isAir())continue;
            mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket(
                Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(target.offset(d.getOpposite())),d.getOpposite(),target.offset(d.getOpposite()),false),
                mc.player.networkHandler.sequenceNumber));
        }
        mc.player.getInventory().selectedSlot=prev;
    }
    private int findObsidian(){
        for(int i=0;i<9;i++) if(mc.player.getInventory().getStack(i).getItem()==Items.OBSIDIAN)return i;
        return-1;
    }
}
