package phantom.modules.impl.combat;

import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;

public class AutoPotModule extends Module {
    private final NumberSetting hpThreshold=addSetting(new NumberSetting("HP Threshold",14.0,1.0,20.0,0.5));
    private long lastUse=0;
    public AutoPotModule(){super("AutoPot","Auto throws health splash potions.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        if(mc.player.getHealth()>hpThreshold.getValue())return;
        if(System.currentTimeMillis()-lastUse<500)return;
        for(int i=0;i<9;i++){
            var s=mc.player.getInventory().getStack(i);
            if(s.getItem()==Items.SPLASH_POTION){
                mc.player.getInventory().selectedSlot=i;
                mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket(Hand.MAIN_HAND, mc.player.networkHandler.sequenceNumber, mc.player.getYaw(), mc.player.getPitch()));
                lastUse=System.currentTimeMillis(); break;
            }
        }
    }
}
