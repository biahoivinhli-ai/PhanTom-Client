package phantom.modules.impl.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.ModeSetting;
import phantom.settings.impl.NumberSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class KillAuraModule extends Module {

    private final ModeSetting   targetMode    = addSetting(new ModeSetting  ("Target",    "Players", List.of("Players","Mobs","All")));
    private final NumberSetting reach         = addSetting(new NumberSetting("Reach",     4.2, 1.0, 6.0, 0.1));
    private final NumberSetting minCPS        = addSetting(new NumberSetting("Min CPS",   8.0, 1.0, 20.0, 1.0));
    private final NumberSetting maxCPS        = addSetting(new NumberSetting("Max CPS",   12.0,1.0, 20.0, 1.0));
    private final BooleanSetting silentAim    = addSetting(new BooleanSetting("Silent Aim", true));
    private final BooleanSetting throughWalls = addSetting(new BooleanSetting("Through Walls", false));
    private final BooleanSetting multiTarget  = addSetting(new BooleanSetting("Multi Target", false));
    private final BooleanSetting autoBlock    = addSetting(new BooleanSetting("Auto Block", false));
    private final ModeSetting   rotMode       = addSetting(new ModeSetting  ("Rotation",  "Silent", List.of("Silent","Legit","None")));

    private final Random rng = new Random();
    private long lastAttack  = 0;
    private Entity currentTarget = null;

    public KillAuraModule() {
        super("KillAura", "Automatically attacks nearby entities.", Category.COMBAT, GLFW.GLFW_KEY_R);
    }

    @SubscribeEvent
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.world == null) return;

        List<Entity> targets = findTargets();
        if (targets.isEmpty()) { currentTarget = null; return; }

        currentTarget = targets.get(0);

        long now    = System.currentTimeMillis();
        double cps  = minCPS.getValue() + rng.nextDouble() * (maxCPS.getValue() - minCPS.getValue());
        long delay  = (long)(1000.0 / cps);
        if (now - lastAttack < delay) return;

        if (!rotMode.getValue().equals("None")) {
            applyRotation(currentTarget);
        }

        List<Entity> toHit = multiTarget.isEnabled() ? targets.subList(0, Math.min(targets.size(), 3))
                                                     : List.of(currentTarget);

        for (Entity t : toHit) {
            mc.player.attack(t);
        }
        mc.player.swingHand(mc.player.getMainHandStack().isEmpty()
                ? net.minecraft.util.Hand.OFF_HAND : net.minecraft.util.Hand.MAIN_HAND);
        lastAttack = now;
    }

    private List<Entity> findTargets() {
        List<Entity> list = new ArrayList<>();
        assert mc.world != null;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            if (!(e instanceof LivingEntity le)) continue;
            if (le.isDead() || le.getHealth() <= 0) continue;

            boolean valid = switch (targetMode.getValue()) {
                case "Players" -> e instanceof PlayerEntity;
                case "Mobs"    -> !(e instanceof PlayerEntity);
                default        -> true;
            };
            if (!valid) continue;

            double dist = mc.player.distanceTo(e);
            if (dist > reach.getValue()) continue;

            if (!throughWalls.isEnabled() && !mc.player.canSee(e)) continue;

            list.add(e);
        }
        list.sort(Comparator.comparingDouble(e -> mc.player.distanceTo(e)));
        return list;
    }

    private void applyRotation(Entity target) {
        double dx = target.getX() - mc.player.getX();
        double dy = (target.getY() + target.getHeight() * 0.5) - (mc.player.getY() + mc.player.getEyeHeight());
        double dz = target.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));

        if (rotMode.getValue().equals("Silent")) {
            // Silent: send packet rotation, don't change visual head
            mc.player.networkHandler.sendPacket(
                new net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.Full(
                    mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                    yaw + rng.nextFloat() * 0.3f - 0.15f,
                    pitch + rng.nextFloat() * 0.2f - 0.1f,
                    mc.player.isOnGround(),
                    mc.player.horizontalCollision
                )
            );
        } else {
            // Legit: smooth rotate actual head
            float diffYaw   = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
            float diffPitch = MathHelper.wrapDegrees(pitch - mc.player.getPitch());
            float speed     = 30f;
            mc.player.setYaw(mc.player.getYaw()   + MathHelper.clamp(diffYaw,   -speed, speed));
            mc.player.setPitch(mc.player.getPitch() + MathHelper.clamp(diffPitch, -speed, speed));
        }
    }

    public Entity getCurrentTarget() { return currentTarget; }
}
