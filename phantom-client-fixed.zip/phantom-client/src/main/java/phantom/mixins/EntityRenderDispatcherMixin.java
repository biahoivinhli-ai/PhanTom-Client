package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.entity.EntityRenderDispatcher.class)
public abstract abstract class EntityRenderDispatcherMixin {}
