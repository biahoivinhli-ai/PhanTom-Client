package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.Camera.class)
public abstract abstract class CameraMixin {}
