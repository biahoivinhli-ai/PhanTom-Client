package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.BackgroundRenderer.class)
public abstract abstract class BackgroundRendererMixin {}
