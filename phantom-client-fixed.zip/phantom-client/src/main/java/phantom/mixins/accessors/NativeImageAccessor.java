package phantom.mixins.accessors;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.MinecraftClient.class)
public interface NativeImageAccessor {}
