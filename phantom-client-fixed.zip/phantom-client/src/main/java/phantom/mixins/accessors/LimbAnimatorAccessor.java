package phantom.mixins.accessors;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.entity.state.LivingEntityRenderState.class)
public interface LimbAnimatorAccessor {}
