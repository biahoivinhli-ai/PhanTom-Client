package phantom.mixins.accessors;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.network.ClientPlayerEntity.class)
public interface PlayerPositionAccessor {}
