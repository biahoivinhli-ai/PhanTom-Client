package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.particle.ParticleManager.class)
public abstract abstract class ParticleManagerMixin {}
