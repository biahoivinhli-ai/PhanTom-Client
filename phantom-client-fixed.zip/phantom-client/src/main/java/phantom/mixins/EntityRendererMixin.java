package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.entity.EntityRenderer.class)
public abstract abstract class EntityRendererMixin {}
