package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.entity.projectile.FireworkRocketEntity.class)
public abstract abstract class FireworkRocketEntityMixin {}
