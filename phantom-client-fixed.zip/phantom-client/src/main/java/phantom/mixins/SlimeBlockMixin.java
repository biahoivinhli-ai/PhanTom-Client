package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.block.SlimeBlock.class)
public abstract abstract class SlimeBlockMixin {}
