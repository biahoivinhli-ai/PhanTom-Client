package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.screen.ingame.HandledScreen.class)
public abstract abstract class HandledScreenMixin {}
