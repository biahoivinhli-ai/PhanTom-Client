package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.entity.decoration.ArmorStandEntity.class)
public abstract abstract class ArmorStandMixin {}
