package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.item.HeldItemRenderer.class)
public abstract abstract class ItemInHandRendererMixin {}
