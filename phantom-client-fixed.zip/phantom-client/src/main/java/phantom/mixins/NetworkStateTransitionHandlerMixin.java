package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.network.ClientConnection.class)
public abstract abstract class NetworkStateTransitionHandlerMixin {}
