package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.hud.BossBarHud.class)
public abstract abstract class BossBarHudMixin {}
