package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.block.Block.class)
public abstract abstract class BlockMixin {}
