package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.screen.ConnectScreen.class)
public abstract abstract class ConnectScreenMixin {}
