package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.Keyboard.class)
public abstract abstract class KeyboardMixin {}
