package phantom.mixins;

import net.minecraft.entity.LivingEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import phantom.Phantom;
import phantom.events.impl.UpdateVelocityEvent;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(at = @At("HEAD"), method = "travel")
    private void onTravel(net.minecraft.util.math.Vec3d input, CallbackInfo ci) {
        Object self = this;
        if (!(self instanceof ClientPlayerEntity player)) return;
        if (Phantom.INSTANCE == null) return;
        var vel = player.getVelocity();
        UpdateVelocityEvent e = Phantom.INSTANCE.eventHandler.dispatchUpdateVelocity(vel.x, vel.y, vel.z);
        player.setVelocity(e.x, e.y, e.z);
    }
}
