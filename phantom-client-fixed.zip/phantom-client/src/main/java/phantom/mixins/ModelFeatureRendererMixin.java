package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.entity.feature.FeatureRendererContext.class)
public abstract abstract class ModelFeatureRendererMixin {}
