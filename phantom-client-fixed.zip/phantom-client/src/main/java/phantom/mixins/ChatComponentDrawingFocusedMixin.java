package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.hud.ChatHud.class)
public abstract abstract class ChatComponentDrawingFocusedMixin {}
