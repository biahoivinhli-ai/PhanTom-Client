package phantom.managers;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import phantom.Phantom;

public class KeybindManager {

    private boolean guiWasOpen = false;
    private boolean prevGuiKey = false;

    public KeybindManager() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        if (client.player == null) return;

        // RightShift opens ClickGui
        boolean guiKey = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (guiKey && !prevGuiKey) {
            if (client.currentScreen == null) {
                client.setScreen(Phantom.INSTANCE.clickGui);
            } else if (client.currentScreen instanceof phantom.gui.ClickGuiScreen) {
                client.setScreen(null);
            }
        }
        prevGuiKey = guiKey;

        // Module keybinds
        if (client.currentScreen != null) return;
        for (var m : Phantom.INSTANCE.moduleManager.getModules()) {
            int key = m.getKeybind();
            if (key == GLFW.GLFW_KEY_UNKNOWN) continue;
            boolean pressed = GLFW.glfwGetKey(client.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
            // debounce handled per-module via wasPressed tracking not shown here
        }
    }
}
