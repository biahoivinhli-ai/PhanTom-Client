#version 150

uniform sampler2D DiffuseSampler;
uniform float     Time;
uniform vec2      InSize;

in  vec2 texCoord;
out vec4 fragColor;

// ──────────────────────────────────────────────────────────────────────────
//  PhanTom GUI Shader – Cinematic Post-Processing
//
//  Effects layered in order:
//    1. Chromatic aberration (RGB channel split on edges)
//    2. Scanline grid (CRT feel)
//    3. Vignette (soft black edge fade)
//    4. Pulse neon bloom (purple/cyan halo at edges)
//    5. Screen-space noise grain (film grain)
//    6. Panning subtle light leak (top glow sweep)
// ──────────────────────────────────────────────────────────────────────────

// Fast hash noise
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

// Smooth noise
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f); // smoothstep
    return mix(
        mix(hash(i + vec2(0,0)), hash(i + vec2(1,0)), f.x),
        mix(hash(i + vec2(0,1)), hash(i + vec2(1,1)), f.x),
        f.y
    );
}

void main() {
    vec2 uv = texCoord;

    // ── 1. CHROMATIC ABERRATION ──────────────────────────────────────────
    // Offset channels outward from center, stronger at corners
    vec2  center  = vec2(0.5);
    vec2  dir     = uv - center;
    float dist    = length(dir);
    float aberr   = 0.0018 * dist * dist * (1.0 + 0.3 * sin(Time * 1.8));

    float r = texture(DiffuseSampler, uv + dir * aberr       ).r;
    float g = texture(DiffuseSampler, uv                      ).g;
    float b = texture(DiffuseSampler, uv - dir * aberr * 0.7 ).b;
    float a = texture(DiffuseSampler, uv                      ).a;

    vec4 color = vec4(r, g, b, a);

    // ── 2. SCANLINES ─────────────────────────────────────────────────────
    // Fine horizontal lines (CRT-ish)
    float scanY    = mod(uv.y * InSize.y, 3.0);
    float scanline = (scanY < 1.5) ? 1.0 : 0.93;
    // Vertical micro-lines (pixel grid feel)
    float scanX    = mod(uv.x * InSize.x, 4.0);
    float vline    = (scanX < 2.0) ? 1.0 : 0.98;
    color.rgb     *= scanline * vline;

    // ── 3. VIGNETTE ───────────────────────────────────────────────────────
    float vig = 1.0 - smoothstep(0.35, 0.95, dist * 1.35);
    color.rgb *= vig;

    // ── 4. NEON EDGE BLOOM ────────────────────────────────────────────────
    // Pulsing purple bloom at screen edges
    float pulse  = 0.5 + 0.5 * sin(Time * 2.3);
    float pulse2 = 0.5 + 0.5 * sin(Time * 1.7 + 1.57);

    float edgeDist  = 1.0 - dist * 1.8;
    float edgeMask  = clamp(edgeDist, 0.0, 1.0);
    edgeMask        = pow(edgeMask, 3.0);

    // Left-right purple/cyan alternating bloom
    float sideGlow  = smoothstep(0.3, 0.0, abs(uv.x - 0.5)) * 0.25 * pulse;
    float topGlow   = smoothstep(0.2, 0.0, uv.y) * 0.18 * pulse2;
    float botGlow   = smoothstep(0.85, 1.0, uv.y) * 0.12 * pulse;

    // Purple bloom
    color.rgb += vec3(0.35, 0.10, 0.80) * sideGlow;
    // Cyan top
    color.rgb += vec3(0.00, 0.55, 0.90) * topGlow;
    // Purple bottom
    color.rgb += vec3(0.40, 0.05, 0.70) * botGlow;

    // ── 5. FILM GRAIN ─────────────────────────────────────────────────────
    // Time-varying noise grain
    vec2  grainUV = uv * InSize * 0.5 + vec2(Time * 7.3, Time * 3.9);
    float grain   = hash(grainUV) * 0.035 - 0.017;
    color.rgb    += grain;

    // ── 6. LIGHT LEAK / SWEEP ────────────────────────────────────────────
    // Slow diagonal sweep bright streak
    float sweep = fract(Time * 0.06);
    float diagF = uv.x * 0.6 + uv.y * 0.4;
    float band  = smoothstep(sweep - 0.04, sweep, diagF)
                - smoothstep(sweep, sweep + 0.04, diagF);
    color.rgb  += vec3(0.12, 0.04, 0.20) * band;

    // ── 7. CONTRAST BOOST ────────────────────────────────────────────────
    // Slight S-curve lift for the neon pop feel
    color.rgb  = color.rgb * 1.08 - 0.04;
    color.rgb  = clamp(color.rgb, 0.0, 1.0);

    fragColor = color;
}
