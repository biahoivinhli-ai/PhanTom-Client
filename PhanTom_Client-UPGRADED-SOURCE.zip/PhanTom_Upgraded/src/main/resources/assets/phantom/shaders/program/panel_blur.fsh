#version 150

//  PhanTom Panel Blur – Frosted Glass Backdrop
//  Applied behind GUI panels for depth separation.
//  Fast 9-tap Gaussian approximation + tint.

uniform sampler2D DiffuseSampler;
uniform vec2      InSize;
uniform float     Time;

in  vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 px = 1.0 / InSize;

    // 9-tap cross blur (fast Gaussian approx, radius 2px)
    vec4 sum = vec4(0.0);
    sum += texture(DiffuseSampler, texCoord + vec2(-2, 0) * px) * 0.10;
    sum += texture(DiffuseSampler, texCoord + vec2(-1, 0) * px) * 0.20;
    sum += texture(DiffuseSampler, texCoord + vec2( 0, 0) * px) * 0.40;
    sum += texture(DiffuseSampler, texCoord + vec2( 1, 0) * px) * 0.20;
    sum += texture(DiffuseSampler, texCoord + vec2( 2, 0) * px) * 0.10;
    sum += texture(DiffuseSampler, texCoord + vec2(0, -2) * px) * 0.10;
    sum += texture(DiffuseSampler, texCoord + vec2(0, -1) * px) * 0.20;
    sum += texture(DiffuseSampler, texCoord + vec2(0,  1) * px) * 0.20;
    sum += texture(DiffuseSampler, texCoord + vec2(0,  2) * px) * 0.10;
    // normalize (sum of weights = 1.6 — intentionally a bit bright)
    sum /= 1.6;

    // Darken + add subtle purple tint (frosted glass feel)
    sum.rgb = sum.rgb * 0.35 + vec3(0.04, 0.02, 0.10);

    // Top-to-bottom frosted glass gradient (lighter top)
    sum.rgb += vec3(0.04, 0.02, 0.08) * (1.0 - texCoord.y);

    fragColor = vec4(sum.rgb, sum.a * 0.88);
}
