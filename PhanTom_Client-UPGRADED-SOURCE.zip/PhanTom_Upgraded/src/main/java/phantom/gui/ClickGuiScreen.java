package phantom.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import phantom.Phantom;
import phantom.modules.Module;
import phantom.settings.Setting;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.NumberSetting;
import phantom.settings.impl.ModeSetting;

import java.util.List;

/**
 * PhanTom ClickGUI – Glassmorphism / Neon Shader-style theme
 * Features:
 *   • Animated gradient panel headers with shimmer sweep
 *   • Glowing enabled-module indicator bars
 *   • Frosted-glass panel background with layered depth
 *   • Smooth slide-in animation per category column
 *   • Neon purple/cyan dual-accent color scheme
 *   • Settings panel with animated slider bars
 *   • Chromatic fringe on active elements
 *   • Scrollable module list (when panel overflows)
 */
public class ClickGuiScreen extends Screen {

    // ── Layout ──────────────────────────────────────────────────────────
    private static final int PANEL_W   = 148;
    private static final int MODULE_H  = 20;
    private static final int HEADER_H  = 26;
    private static final int PAD       = 8;
    private static final int CORNER    = 4;

    // ── Primary palette ─────────────────────────────────────────────────
    private static final int ACCENT_PRI  = 0xFF9B59FF; // purple
    private static final int ACCENT_SEC  = 0xFF00E5FF; // cyan
    private static final int ACCENT_D    = 0xFF6B3FA0; // dark purple
    private static final int ACCENT_MID  = 0xFF7B48CF; // mid purple
    private static final int NEON_GREEN  = 0xFF39FF14; // enabled ping

    // ── Panel glass layers ───────────────────────────────────────────────
    private static final int GLASS_BASE  = 0xD8101020; // deep navy
    private static final int GLASS_OVER  = 0x14FFFFFF; // frosted sheen
    private static final int GLASS_EDGE  = 0x55FFFFFF; // border glint
    private static final int SHADOW      = 0x88000000;

    // ── Text ─────────────────────────────────────────────────────────────
    private static final int TEXT_ON     = 0xFFEEE8FF;
    private static final int TEXT_OFF    = 0xFF7777AA;
    private static final int TEXT_ACCENT = 0xFFBBAFFF;
    private static final int TEXT_DIM    = 0xFF444466;

    // ── Hover / selection ────────────────────────────────────────────────
    private static final int HOVER_BG    = 0x3300E5FF; // cyan ghost
    private static final int SEL_BG      = 0x449B59FF; // purple tint

    // ── State ─────────────────────────────────────────────────────────────
    private Module hoveredModule  = null;
    private Module expandedModule = null;
    private float  globalTime     = 0f;      // continuous clock for animations
    private float  openAnim       = 0f;      // 0→1 open ease

    // Per-module hover brightness (for smooth hover fade)
    private java.util.Map<Module, Float> hoverFade = new java.util.HashMap<>();

    public ClickGuiScreen() {
        super(Text.literal("PhanTom"));
    }

    @Override
    protected void init() {
        openAnim = 0f;
        hoverFade.clear();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MAIN RENDER
    // ─────────────────────────────────────────────────────────────────────
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        globalTime += delta * 0.05f;
        openAnim    = Math.min(1f, openAnim + delta * 0.06f);
        float ease  = 1f - (1f - openAnim) * (1f - openAnim); // ease-out quad

        // ── Dimmed scene backdrop with top-left radial glow ──────────────
        renderBackdrop(ctx, ease);

        // ── Top chrome bar ────────────────────────────────────────────────
        renderTopBar(ctx);

        // ── Category columns ──────────────────────────────────────────────
        hoveredModule = null;
        Module.Category[] cats = Module.Category.values();
        int startX = PAD + (int)((1f - ease) * -60);

        for (int c = 0; c < cats.length; c++) {
            Module.Category cat = cats[c];
            List<Module> mods = Phantom.INSTANCE.moduleManager.getByCategory(cat);
            if (mods.isEmpty()) continue;

            // stagger per column
            float colEase = Math.min(1f, ease * 1.3f - c * 0.07f);
            if (colEase <= 0f) continue;
            int colOff = (int)((1f - colEase) * -40);

            int x  = startX + c * (PANEL_W + PAD) + colOff;
            int y  = PAD + 34;
            int ph = HEADER_H + countVisible(mods) * MODULE_H + 6;

            renderPanel(ctx, x, y, PANEL_W, ph, c, cat, mods, mouseX, mouseY, colEase);
        }

        // ── Settings panel ────────────────────────────────────────────────
        if (expandedModule != null) {
            renderSettingsPanel(ctx, mouseX, mouseY);
        }

        // ── Cursor neon dot ───────────────────────────────────────────────
        renderCursor(ctx, mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BACKDROP
    // ─────────────────────────────────────────────────────────────────────
    private void renderBackdrop(DrawContext ctx, float ease) {
        // Base dark gradient
        ctx.fillGradient(0, 0, this.width, this.height, 0xCC060610, 0xDD10081A);

        // Animated radial-like "glow blobs" (horizontal gradient bands)
        float t = globalTime;
        int blobY1 = (int)(this.height * (0.25f + 0.08f * (float)Math.sin(t * 1.1f)));
        int blobY2 = (int)(this.height * (0.65f + 0.07f * (float)Math.sin(t * 0.8f + 2f)));

        // blob 1 – purple
        ctx.fillGradient(0, blobY1 - 80, this.width / 2, blobY1 + 80,
                0x00000000, 0x12A050FF);
        ctx.fillGradient(this.width / 2, blobY1 - 80, this.width, blobY1 + 80,
                0x12A050FF, 0x00000000);

        // blob 2 – cyan
        ctx.fillGradient(0, blobY2 - 60, this.width, blobY2 + 60,
                0x0000E5FF, 0x0800E5FF);

        // Top scan-line effect (very subtle)
        int scanY = (int)((globalTime * 60f) % this.height);
        ctx.fill(0, scanY, this.width, scanY + 1, 0x0600E5FF);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  TOP CHROME BAR
    // ─────────────────────────────────────────────────────────────────────
    private void renderTopBar(DrawContext ctx) {
        // Shadow under
        ctx.fillGradient(0, 28, this.width, 32, 0x88000000, 0x00000000);

        // Bar bg
        ctx.fill(0, 0, this.width, 28, 0xF00A0A18);

        // Shimmer sweep across top bar
        float sw = (globalTime * 0.4f) % 1.0f;
        int shimX = (int)(sw * this.width);
        ctx.fillGradient(shimX - 80, 0, shimX, 28, 0x00FFFFFF, 0x0CFFFFFF);
        ctx.fillGradient(shimX, 0, shimX + 80, 28, 0x0CFFFFFF, 0x00FFFFFF);

        // Bottom accent line – dual color gradient
        ctx.fillGradient(0, 27, this.width / 2, 28, ACCENT_PRI, ACCENT_SEC);
        ctx.fillGradient(this.width / 2, 27, this.width, 28, ACCENT_SEC, ACCENT_PRI);

        // Branding
        String brand = "✦ PhanTom Client";
        ctx.drawTextWithShadow(this.textRenderer, brand, 12, 9, ACCENT_PRI);

        // Hint text
        String hint = "RShift close  │  RMB settings";
        int hw = this.textRenderer.getWidth(hint);
        ctx.drawTextWithShadow(this.textRenderer, hint, this.width - hw - 12, 9, TEXT_DIM);

        // Version tag
        String ver = "v1.0";
        int vw = this.textRenderer.getWidth(ver);
        int tagX = 12 + this.textRenderer.getWidth(brand) + 8;
        ctx.fill(tagX, 7, tagX + vw + 6, 20, 0xFF1A0A2E);
        ctx.fill(tagX, 7, tagX + vw + 6, 8, ACCENT_D);
        ctx.drawTextWithShadow(this.textRenderer, ver, tagX + 3, 9, ACCENT_SEC);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PANEL (single category column)
    // ─────────────────────────────────────────────────────────────────────
    private void renderPanel(DrawContext ctx, int x, int y, int w, int ph,
                             int colIdx, Module.Category cat,
                             List<Module> mods, int mx, int my, float ease) {
        // ── Drop shadow ───────────────────────────────────────────────────
        ctx.fillGradient(x + 6, y + ph, x + w - 6, y + ph + 8, SHADOW, 0x00000000);
        ctx.fillGradient(x + w, y + 6, x + w + 8, y + ph - 6, SHADOW, 0x00000000);

        // ── Glass body ────────────────────────────────────────────────────
        // Main fill
        ctx.fill(x, y, x + w, y + ph, GLASS_BASE);
        // Inner frosted sheen (top-left lighter)
        ctx.fillGradient(x, y, x + w, y + ph / 2, GLASS_OVER, 0x00000000);
        // Edge glint (left 1px, top 1px)
        ctx.fill(x, y, x + 1, y + ph, GLASS_EDGE);
        ctx.fill(x, y, x + w, y + 1, GLASS_EDGE);
        // Right/bottom inner shadow
        ctx.fill(x + w - 1, y, x + w, y + ph, 0x22000000);
        ctx.fill(x, y + ph - 1, x + w, y + ph, 0x22000000);

        // ── Header gradient bar ───────────────────────────────────────────
        // Choose accent per category cycling
        int a1 = catColor1(colIdx);
        int a2 = catColor2(colIdx);
        ctx.fillGradient(x, y, x + w, y + HEADER_H, a1, a2);
        // Shimmer over header
        float hs = (globalTime * 0.3f + colIdx * 0.2f) % 1.0f;
        int hsx = x + (int)(hs * w);
        ctx.fillGradient(hsx - 30, y, hsx, y + HEADER_H, 0x00FFFFFF, 0x18FFFFFF);
        ctx.fillGradient(hsx, y, hsx + 30, y + HEADER_H, 0x18FFFFFF, 0x00FFFFFF);
        // Bottom accent line under header
        ctx.fillGradient(x, y + HEADER_H - 2, x + w, y + HEADER_H, a2, a1);

        // Category name
        ctx.drawTextWithShadow(this.textRenderer,
                "▸ " + cat.name, x + 10, y + 8, TEXT_ON);

        // Module count badge
        long enabledCount = mods.stream().filter(Module::isEnabled).count();
        String badge = enabledCount + "/" + mods.stream().filter(Module::isVisible).count();
        int bw = this.textRenderer.getWidth(badge);
        ctx.fill(x + w - bw - 8, y + 7, x + w - 4, y + HEADER_H - 5, 0x33000000);
        ctx.drawTextWithShadow(this.textRenderer, badge, x + w - bw - 6, y + 8,
                enabledCount > 0 ? ACCENT_SEC : TEXT_DIM);

        // ── Module rows ───────────────────────────────────────────────────
        int ry = y + HEADER_H + 3;
        for (Module m : mods) {
            if (!m.isVisible()) continue;

            boolean hover = mx >= x && mx <= x + w && my >= ry && my <= ry + MODULE_H;
            boolean on    = m.isEnabled();

            if (hover) hoveredModule = m;

            // Hover fade
            float hf = hoverFade.getOrDefault(m, 0f);
            hf = hover ? Math.min(1f, hf + 0.15f) : Math.max(0f, hf - 0.1f);
            hoverFade.put(m, hf);

            // Row background
            if (on) {
                // Enabled glow row
                ctx.fillGradient(x + 1, ry, x + w - 1, ry + MODULE_H,
                        blend(0x0A9B59FF, 0x009B59FF, hf), 0x00000000);
            }
            if (hf > 0.01f) {
                ctx.fill(x + 1, ry, x + w - 1, ry + MODULE_H,
                        alphaScale(HOVER_BG, hf));
            }

            // ── Left indicator bar ─────────────────────────────────────────
            if (on) {
                // Glowing neon bar when enabled
                ctx.fill(x + 2, ry + 2, x + 5, ry + MODULE_H - 2, ACCENT_PRI);
                // Chromatic fringe above/below
                ctx.fill(x + 2, ry + 2, x + 3, ry + 4, ACCENT_SEC);
                ctx.fill(x + 2, ry + MODULE_H - 4, x + 3, ry + MODULE_H - 2, NEON_GREEN);
            } else {
                ctx.fill(x + 2, ry + 3, x + 4, ry + MODULE_H - 3, 0xFF2A2A40);
            }

            // ── Module name ────────────────────────────────────────────────
            int textCol = on ? TEXT_ON : TEXT_OFF;
            if (hf > 0.5f && !on) textCol = blend(TEXT_OFF, TEXT_ACCENT, (hf - 0.5f) * 2f);
            ctx.drawTextWithShadow(this.textRenderer, m.getName(), x + 10, ry + 6, textCol);

            // ── Status dot ────────────────────────────────────────────────
            int dotColor = on ? 0xFF39FF14 : 0xFF333344;
            ctx.fill(x + w - 10, ry + 7, x + w - 7, ry + 10, dotColor);

            // ── Keybind ────────────────────────────────────────────────────
            if (m.getKeybind() != GLFW.GLFW_KEY_UNKNOWN) {
                String key = GLFW.glfwGetKeyName(m.getKeybind(), 0);
                if (key != null) {
                    key = "[" + key.toUpperCase() + "]";
                    int kw = this.textRenderer.getWidth(key);
                    ctx.drawTextWithShadow(this.textRenderer, key,
                            x + w - kw - 14, ry + 6, TEXT_DIM);
                }
            }

            // ── Row separator ──────────────────────────────────────────────
            ctx.fill(x + 8, ry + MODULE_H - 1, x + w - 8, ry + MODULE_H, 0x15FFFFFF);

            ry += MODULE_H;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SETTINGS PANEL
    // ─────────────────────────────────────────────────────────────────────
    private void renderSettingsPanel(DrawContext ctx, int mx, int my) {
        List<Setting<?>> settings = expandedModule.getSettings();
        int pw = 220;
        int ph = 40 + Math.max(1, settings.size()) * 22 + 12;
        int px = this.width - pw - 10;
        int py = 36;

        // Drop shadow
        ctx.fillGradient(px + 8, py + ph, px + pw - 8, py + ph + 10, SHADOW, 0x00000000);
        ctx.fillGradient(px + pw, py + 8, px + pw + 10, py + ph - 8, SHADOW, 0x00000000);

        // Glass body
        ctx.fill(px, py, px + pw, py + ph, 0xEE0D0D1C);
        ctx.fillGradient(px, py, px + pw, py + 40, 0x18FFFFFF, 0x00000000);
        ctx.fill(px, py, px + 1, py + ph, ACCENT_PRI);           // left accent bar
        ctx.fill(px, py, px + pw, py + 1, GLASS_EDGE);           // top glint
        ctx.fill(px + pw - 1, py, px + pw, py + ph, 0x33000000); // right shadow

        // Header
        ctx.fillGradient(px + 1, py, px + pw, py + 38, 0xFF110820, 0xFF0D0D1C);
        ctx.fill(px + 1, py + 38, px + pw, py + 39, ACCENT_D);

        ctx.drawTextWithShadow(this.textRenderer,
                expandedModule.getName(), px + 10, py + 8, ACCENT_PRI);
        ctx.drawTextWithShadow(this.textRenderer,
                "⚙ Settings", px + 10, py + 22, 0xFF777799);

        // Settings list
        int sy = py + 46;
        if (settings.isEmpty()) {
            ctx.drawTextWithShadow(this.textRenderer, "No settings available.",
                    px + 12, sy, TEXT_DIM);
        } else {
            for (Setting<?> s : settings) {
                renderSettingRow(ctx, s, px + 4, sy, pw - 8, mx, my);
                sy += 22;
            }
        }

        // Close hint
        ctx.drawTextWithShadow(this.textRenderer,
                "RMB to close", px + pw - 68, py + ph - 12, TEXT_DIM);
    }

    private void renderSettingRow(DrawContext ctx, Setting<?> s,
                                  int x, int y, int w, int mx, int my) {
        // Row bg
        ctx.fill(x, y, x + w, y + 20, 0x22FFFFFF);
        ctx.fill(x, y + 19, x + w, y + 20, 0x11FFFFFF);

        String name = s.getName();
        ctx.drawTextWithShadow(this.textRenderer, name, x + 6, y + 6, TEXT_ACCENT);

        String val = s.getValueString();

        if (s instanceof BooleanSetting bs) {
            // Toggle pill
            boolean on = bs.isEnabled();
            int pillX = x + w - 34;
            ctx.fill(pillX, y + 5, pillX + 28, y + 15, on ? 0xFF1A0A3A : 0xFF1A1A2A);
            ctx.fill(pillX + (on ? 14 : 2), y + 7, pillX + (on ? 26 : 14), y + 13,
                    on ? ACCENT_PRI : 0xFF444466);
            ctx.drawTextWithShadow(this.textRenderer,
                    on ? "ON" : "OFF", pillX + 3, y + 6, on ? ACCENT_SEC : TEXT_DIM);

        } else if (s instanceof NumberSetting ns) {
            // Slider bar
            double min  = ns.getMin();
            double max  = ns.getMax();
            double cur  = (double)(Number) ns.getValue();
            float  pct  = (float)((cur - min) / (max - min));
            int barX = x + w / 2;
            int barW = w / 2 - 6;
            ctx.fill(barX, y + 8, barX + barW, y + 12, 0xFF1A1A30);
            ctx.fillGradient(barX, y + 8, barX + (int)(pct * barW), y + 12,
                    ACCENT_D, ACCENT_PRI);
            // Thumb
            int thumbX = barX + (int)(pct * barW) - 2;
            ctx.fill(thumbX, y + 6, thumbX + 4, y + 14, ACCENT_SEC);
            ctx.drawTextWithShadow(this.textRenderer,
                    String.format("%.1f", cur), barX + barW - 18, y + 6, TEXT_ACCENT);

        } else {
            // Generic value right-aligned
            int vw = this.textRenderer.getWidth(val);
            ctx.drawTextWithShadow(this.textRenderer, val, x + w - vw - 6, y + 6, ACCENT_SEC);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  CURSOR NEON DOT
    // ─────────────────────────────────────────────────────────────────────
    private void renderCursor(DrawContext ctx, int mx, int my) {
        float pulse = 0.6f + 0.4f * (float)Math.sin(globalTime * 6f);
        int col = alphaScale(ACCENT_SEC, pulse);
        ctx.fill(mx - 2, my - 2, mx + 2, my + 2, col);
        ctx.fill(mx - 1, my - 1, mx + 1, my + 1, 0xCCFFFFFF);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INPUT
    // ─────────────────────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (hoveredModule != null) {
            if (button == 0) {
                hoveredModule.toggle();
                return true;
            } else if (button == 1) {
                expandedModule = (expandedModule == hoveredModule) ? null : hoveredModule;
                return true;
            }
        }
        if (button == 0 && expandedModule != null) expandedModule = null;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT || keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }

    // ─────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────
    private int countVisible(List<Module> mods) {
        int n = 0;
        for (Module m : mods) if (m.isVisible()) n++;
        return n;
    }

    /** Per-category gradient accent 1 */
    private int catColor1(int idx) {
        return switch (idx % 5) {
            case 0 -> 0xFF1A0A2E; // combat – deep purple
            case 1 -> 0xFF0A1A2E; // movement – deep navy
            case 2 -> 0xFF0A2E1A; // render – deep teal
            case 3 -> 0xFF2E1A0A; // misc – deep amber
            default-> 0xFF1A1A2E;
        };
    }

    /** Per-category gradient accent 2 */
    private int catColor2(int idx) {
        return switch (idx % 5) {
            case 0 -> 0xFF2D0A5A; // combat
            case 1 -> 0xFF0A2D5A; // movement
            case 2 -> 0xFF0A5A2D; // render
            case 3 -> 0xFF5A2D0A; // misc
            default-> 0xFF2D2D5A;
        };
    }

    /** Linear blend two ARGB colors by t in [0,1] */
    private static int blend(int c1, int c2, float t) {
        int a = lerp((c1 >> 24) & 0xFF, (c2 >> 24) & 0xFF, t);
        int r = lerp((c1 >> 16) & 0xFF, (c2 >> 16) & 0xFF, t);
        int g = lerp((c1 >>  8) & 0xFF, (c2 >>  8) & 0xFF, t);
        int b = lerp( c1        & 0xFF,  c2        & 0xFF, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Scale alpha of an ARGB color by factor f in [0,1] */
    private static int alphaScale(int color, float f) {
        int a = (int)(((color >> 24) & 0xFF) * f) & 0xFF;
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private static int lerp(int a, int b, float t) {
        return (int)(a + (b - a) * t);
    }
}
