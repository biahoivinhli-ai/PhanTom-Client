package phantom.mixins;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import phantom.Phantom;
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(at=@At("TAIL"), method="tick")
    private void onTick(CallbackInfo ci){
        if(Phantom.INSTANCE!=null) Phantom.INSTANCE.eventHandler.dispatchTickPost();
    }
}
