package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.entity.LivingEntityRenderer.class)
public class LivingEntityRendererMixin {}
