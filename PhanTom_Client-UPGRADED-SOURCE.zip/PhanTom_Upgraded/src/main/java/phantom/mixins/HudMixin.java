package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.hud.InGameHud.class)
public class HudMixin {}
