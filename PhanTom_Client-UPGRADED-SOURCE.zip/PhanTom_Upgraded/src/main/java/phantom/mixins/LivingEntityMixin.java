package phantom.mixins;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.util.math.Vec3d;
import phantom.Phantom;
import phantom.events.impl.UpdateVelocityEvent;
@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(at=@At("HEAD"), method="applyDamage")
    private void onApplyDamage(CallbackInfo ci){}

    @ModifyVariable(at=@At("STORE"), method="travel", argsOnly=false, index=0)
    private Vec3d onTravel(Vec3d velocity){
        Object self=this;
        if(!(self instanceof net.minecraft.client.network.ClientPlayerEntity)) return velocity;
        if(Phantom.INSTANCE==null)return velocity;
        UpdateVelocityEvent e=Phantom.INSTANCE.eventHandler.dispatchUpdateVelocity(velocity.x,velocity.y,velocity.z);
        return new Vec3d(e.x,e.y,e.z);
    }
}
