package phantom.mixins;

import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import phantom.Phantom;
import phantom.gui.ClickGuiScreen;

@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void phantom$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return;

        // Right Shift opens / closes ClickGUI
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (mc.currentScreen instanceof ClickGuiScreen) {
                mc.setScreen(null);
            } else if (mc.currentScreen == null) {
                if (Phantom.INSTANCE != null && Phantom.INSTANCE.clickGui != null) {
                    mc.setScreen(Phantom.INSTANCE.clickGui);
                }
            }
        }
    }
}
