package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.MinecraftClient.class)
public class EntityRenderDispatcherMixin {}
