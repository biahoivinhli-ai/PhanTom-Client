package phantom.mixins.accessors;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(Entity.class)
public interface EntityFlagAccessor {
    @Accessor("flags") net.minecraft.entity.data.TrackedData<Byte> getFlags();
}