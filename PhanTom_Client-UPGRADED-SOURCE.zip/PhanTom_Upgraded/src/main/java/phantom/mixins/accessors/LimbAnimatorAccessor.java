package phantom.mixins.accessors;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(LivingEntityRenderState.class)
public interface LimbAnimatorAccessor {
    @Accessor float getLimbFrequency();
    @Accessor void  setLimbFrequency(float v);
}