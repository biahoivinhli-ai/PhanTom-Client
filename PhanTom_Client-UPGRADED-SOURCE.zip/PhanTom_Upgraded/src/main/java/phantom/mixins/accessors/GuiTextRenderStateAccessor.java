package phantom.mixins.accessors;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.MinecraftClient;
@Mixin(MinecraftClient.class)
public interface GuiTextRenderStateAccessor {}
