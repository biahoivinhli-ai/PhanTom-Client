package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.font.TextRenderer.class)
public class FontMixin {}
