package phantom.mixins;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * PhanTom Title Screen – Cinematic neon intro overlay.
 *
 * Visual layers (render order, RETURN inject so we draw OVER Mojang UI):
 *   1. Dark gradient veil (semi-opaque, dims vanilla background)
 *   2. Animated particle rain (falling purple dots + trails)
 *   3. Horizontal neon scan-line sweeps
 *   4. Bottom chrome bar with branding
 *   5. Top accent line (dual-gradient purple→cyan)
 *   6. "PhanTom Client" large header with subtitle fade
 *   7. Corner tech brackets
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

    // Persistent time for animation continuity
    private static float t          = 0f;
    // Particle system: [x, y, speed, opacity, size]
    private static float[][] parts  = null;
    private static final int  N_PARTS = 60;

    protected TitleScreenMixin(Text title) { super(title); }

    // ── Init particles once ────────────────────────────────────────────────
    private static void ensureParticles(int w, int h) {
        if (parts != null) return;
        parts = new float[N_PARTS][5];
        java.util.Random rng = new java.util.Random(0xDEAD_BEEF_CAF_EBABEL);
        for (int i = 0; i < N_PARTS; i++) {
            parts[i][0] = rng.nextFloat() * w;          // x
            parts[i][1] = rng.nextFloat() * h;          // y
            parts[i][2] = 0.4f + rng.nextFloat() * 0.9f; // speed
            parts[i][3] = 0.2f + rng.nextFloat() * 0.8f; // opacity
            parts[i][4] = 1f + rng.nextFloat();          // size (1 or 2)
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void phantom$renderOverlay(DrawContext ctx, int mx, int my,
                                       float delta, CallbackInfo ci) {
        t += delta * 0.025f;
        int W = this.width, H = this.height;

        ensureParticles(W, H);

        // ── 1. Dark veil ─────────────────────────────────────────────────
        ctx.fillGradient(0, 0, W, H / 2, 0xBB050510, 0x55050510);
        ctx.fillGradient(0, H / 2, W, H, 0x55050510, 0xCC050510);

        // ── 2. Particle rain ──────────────────────────────────────────────
        for (int i = 0; i < N_PARTS; i++) {
            // update
            parts[i][1] += parts[i][2] * delta * 1.2f;
            if (parts[i][1] > H + 4) {
                parts[i][1] = -4;
                parts[i][0] = (float)(Math.random() * W);
            }
            // color: alternating purple / cyan / white
            int col;
            float hue = (i / (float) N_PARTS);
            if (hue < 0.4f)      col = 0xFF9B59FF;
            else if (hue < 0.7f) col = 0xFF00E5FF;
            else                  col = 0xFFBBBBDD;

            int alpha = (int)(parts[i][3] * 255) & 0xFF;
            col = (col & 0x00FFFFFF) | (alpha << 24);

            int px = (int) parts[i][0];
            int py = (int) parts[i][1];
            int sz = (int) parts[i][4];

            // dot
            ctx.fill(px, py, px + sz, py + sz, col);
            // fading trail above
            int trailAlpha = alpha / 4;
            ctx.fill(px, py - 4, px + sz, py, (col & 0x00FFFFFF) | (trailAlpha << 24));
        }

        // ── 3. Scan-line sweeps ───────────────────────────────────────────
        // Slow sweeping bright horizontal line
        int scanY = (int)(((t * 0.28f) % 1.0f) * H);
        ctx.fill(0, scanY - 1, W, scanY,     0x09FFFFFF);
        ctx.fill(0, scanY,     W, scanY + 1, 0x16FFFFFF);
        ctx.fill(0, scanY + 1, W, scanY + 2, 0x09FFFFFF);

        // Secondary faster sweep – neon purple
        int scanY2 = (int)(((t * 0.47f + 0.5f) % 1.0f) * H);
        ctx.fill(0, scanY2, W, scanY2 + 1, 0x229B59FF);

        // ── 4. Bottom chrome bar ──────────────────────────────────────────
        ctx.fillGradient(0, H - 32, W, H, 0x00050510, 0xEE050510);
        ctx.fill(0, H - 32, W, H, 0xCC07071A);
        // bottom accent line
        ctx.fillGradient(0, H - 1, W / 2, H, 0xFF9B59FF, 0xFF00E5FF);
        ctx.fillGradient(W / 2, H - 1, W, H, 0xFF00E5FF, 0xFF9B59FF);

        String ver = "PhanTom Client  ·  v1.0  ·  AutoShop + PhaseSurround";
        ctx.drawTextWithShadow(this.textRenderer, ver, 14, H - 22, 0xFF9966CC);

        // ── 5. Top accent ─────────────────────────────────────────────────
        ctx.fill(0, 0, W, 2, 0xFF070715);
        ctx.fillGradient(0, 2, W / 2, 4, 0xFF9B59FF, 0xFF00E5FF);
        ctx.fillGradient(W / 2, 2, W, 4, 0xFF00E5FF, 0xFF9B59FF);

        // Left stripe
        ctx.fill(0, 0, 3, H, 0xAA9B59FF);
        ctx.fill(3, 0, 4, H, 0x4400E5FF);

        // Right stripe
        ctx.fill(W - 4, 0, W - 3, H, 0x4400E5FF);
        ctx.fill(W - 3, 0, W, H, 0xAA9B59FF);

        // ── 6. Header branding ────────────────────────────────────────────
        // Rendered in center-top area
        int centerX = W / 2;
        int headerY = H / 4;

        String title = "PhanTom";
        String sub   = "Client";
        int tw = this.textRenderer.getWidth(title);
        int sw = this.textRenderer.getWidth(sub);

        // Glow bg behind text
        float gPulse = 0.5f + 0.5f * (float)Math.sin(t * 3.1f);
        ctx.fillGradient(
            centerX - 80, headerY - 6,
            centerX + 80, headerY + 22,
            (int)(0x22 * gPulse) << 24 | 0x9B59FF,
            0x009B59FF
        );

        // Main brand text (scaled feel via double-draw with 1px offset)
        ctx.drawTextWithShadow(this.textRenderer, title,
                centerX - tw / 2, headerY, 0xFF9B59FF);
        ctx.drawTextWithShadow(this.textRenderer, sub,
                centerX + tw / 2 - sw / 2 + tw / 2 + 4, headerY, 0xFF00E5FF);

        // Subtitle
        String tagline = "✦  Forged in the Storm  ✦";
        float fade = 0.5f + 0.5f * (float)Math.sin(t * 2.0f);
        int tagAlpha = (int)(fade * 180);
        int tagColor = (tagAlpha << 24) | 0x7777AA;
        int tgw = this.textRenderer.getWidth(tagline);
        ctx.drawTextWithShadow(this.textRenderer, tagline,
                centerX - tgw / 2, headerY + 14, tagColor);

        // ── 7. Corner tech brackets ───────────────────────────────────────
        int bLen = 12, bThk = 2, margin = 8;
        int bracketCol = 0xAA9B59FF;
        // TL
        ctx.fill(margin, margin, margin + bLen, margin + bThk, bracketCol);
        ctx.fill(margin, margin, margin + bThk, margin + bLen, bracketCol);
        // TR
        ctx.fill(W - margin - bLen, margin, W - margin, margin + bThk, bracketCol);
        ctx.fill(W - margin - bThk, margin, W - margin, margin + bLen, bracketCol);
        // BL
        ctx.fill(margin, H - margin - bThk, margin + bLen, H - margin, bracketCol);
        ctx.fill(margin, H - margin - bLen, margin + bThk, H - margin, bracketCol);
        // BR
        ctx.fill(W - margin - bLen, H - margin - bThk, W - margin, H - margin, bracketCol);
        ctx.fill(W - margin - bThk, H - margin - bLen, W - margin, H - margin, bracketCol);
    }
}
