package phantom.managers;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import phantom.Phantom;
import phantom.modules.Module;
import phantom.settings.Setting;
import phantom.settings.impl.*;

import java.io.*;
import java.nio.file.*;

public class ConfigManager {
    private final Path configDir;
    private final Path configFile;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ConfigManager() {
        configDir  = FabricLoader.getInstance().getConfigDir().resolve("phantom");
        configFile = configDir.resolve("config.json");
        try { Files.createDirectories(configDir); } catch (IOException e) { e.printStackTrace(); }
    }

    public void save() {
        JsonObject root = new JsonObject();
        for (Module m : Phantom.INSTANCE.moduleManager.getModules()) {
            JsonObject obj = new JsonObject();
            obj.addProperty("enabled",  m.isEnabled());
            obj.addProperty("keybind",  m.getKeybind());
            JsonObject settings = new JsonObject();
            for (Setting<?> s : m.getSettings()) {
                settings.addProperty(s.getName(), s.getValueString());
            }
            obj.add("settings", settings);
            root.add(m.getName(), obj);
        }
        try (Writer w = Files.newBufferedWriter(configFile)) {
            gson.toJson(root, w);
        } catch (IOException e) { e.printStackTrace(); }
    }

    public void load() {
        if (!Files.exists(configFile)) return;
        try (Reader r = Files.newBufferedReader(configFile)) {
            JsonObject root = gson.fromJson(r, JsonObject.class);
            if (root == null) return;
            for (Module m : Phantom.INSTANCE.moduleManager.getModules()) {
                if (!root.has(m.getName())) continue;
                JsonObject obj = root.getAsJsonObject(m.getName());
                if (obj.has("enabled") && obj.get("enabled").getAsBoolean()) m.setEnabled(true);
                if (obj.has("keybind")) m.setKeybind(obj.get("keybind").getAsInt());
                if (!obj.has("settings")) continue;
                JsonObject settings = obj.getAsJsonObject("settings");
                for (Setting<?> s : m.getSettings()) {
                    if (!settings.has(s.getName())) continue;
                    String val = settings.get(s.getName()).getAsString();
                    applySetting(s, val);
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    @SuppressWarnings("unchecked")
    private void applySetting(Setting<?> s, String val) {
        try {
            if (s instanceof BooleanSetting b) b.setValue(Boolean.parseBoolean(val));
            else if (s instanceof NumberSetting n) n.setValue(Double.parseDouble(val));
            else if (s instanceof ModeSetting   m) m.setValue(val);
            else if (s instanceof StringSetting st) st.setValue(val);
            else if (s instanceof ColorSetting  c) c.setValue(Integer.parseInt(val.replace("#",""), 16));
            else if (s instanceof BindSetting   bi) bi.setValue(Integer.parseInt(val));
        } catch (Exception ignored) {}
    }
}
