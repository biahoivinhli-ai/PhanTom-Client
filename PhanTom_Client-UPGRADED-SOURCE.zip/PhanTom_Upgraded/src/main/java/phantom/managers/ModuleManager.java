package phantom.managers;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
import phantom.modules.impl.combat.*;
import phantom.modules.impl.movement.*;
import phantom.modules.impl.render.*;
import phantom.modules.impl.misc.*;
import phantom.Phantom;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // --- Combat ---
        add(new KillAuraModule());
        add(new VelocityModule());
        add(new AutoCrystalModule());
        add(new CriticalsModule());
        add(new AutoTotemModule());
        add(new AutoArmorModule());
        add(new SurroundModule());
        add(new PhaseSurroundModule());
        add(new HoleFillModule());
        add(new AutoMineModule());
        add(new AutoPotModule());

        // --- Movement ---
        add(new SpeedModule());
        add(new SprintModule());
        add(new StepModule());
        add(new NoFallModule());
        add(new AirJumpModule());
        add(new FastClimbModule());
        add(new FreecamModule());

        // --- Render ---
        add(new ESPModule());
        add(new ChamModule());
        add(new FullbrightModule());
        add(new HUDModule());
        add(new TracersModule());
        add(new StorageESPModule());
        add(new NoRenderModule());
        add(new NameTagsModule());
        add(new AntiBlindModule());

        // --- Misc ---
        add(new AutoShopModule());
        add(new AutoReconnectModule());
        add(new NoPacketKickModule());
        add(new FastLatencyModule());
        add(new SpammerModule());
        add(new BetterChatModule());
        add(new AntiAFKModule());

        // Keybind tick
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.currentScreen != null) return;
            for (Module m : modules) {
                if (m.getKeybind() == GLFW.GLFW_KEY_UNKNOWN) continue;
                if (GLFW.glfwGetKey(client.getWindow().getHandle(), m.getKeybind()) == GLFW.GLFW_PRESS) {
                    // debounce handled inside modules via toggle flags
                }
            }
        });

        Phantom.LOG.info("[Phantom] Loaded " + modules.size() + " modules.");
    }

    private void add(Module m) {
        modules.add(m);
    }

    public List<Module> getModules()                    { return modules; }
    public List<Module> getByCategory(Module.Category c) {
        return modules.stream().filter(m -> m.getCategory() == c).toList();
    }
    public Module getModule(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) modules.stream().filter(m -> m.getClass() == clazz).findFirst().orElse(null);
    }
}
