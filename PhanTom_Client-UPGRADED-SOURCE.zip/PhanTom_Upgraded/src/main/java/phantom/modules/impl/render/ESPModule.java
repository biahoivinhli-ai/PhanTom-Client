package phantom.modules.impl.render;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.RenderOverlayEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.ModeSetting;
import java.util.List;
public class ESPModule extends Module {
    private final ModeSetting mode=addSetting(new ModeSetting("Mode","Box",List.of("Box","Outline","Glow")));
    private final BooleanSetting players=addSetting(new BooleanSetting("Players",true));
    private final BooleanSetting mobs=addSetting(new BooleanSetting("Mobs",false));
    public ESPModule(){super("ESP","Renders entity ESP boxes.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onRender(RenderOverlayEvent e){
        if(mc.player==null||mc.world==null)return;
        for(var ent:mc.world.getEntities()){
            if(ent==mc.player)continue;
            boolean isPlayer=ent instanceof PlayerEntity;
            if(isPlayer&&!players.isEnabled())continue;
            if(!isPlayer&&!mobs.isEnabled())continue;
            // ESP rendering handled via RenderWorldEvent in separate renderer
        }
    }
}