package phantom.modules.impl.combat;

import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.NumberSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AutoCrystalModule extends Module {

    private final NumberSetting placeRange  = addSetting(new NumberSetting("Place Range",  4.0, 1.0, 6.0, 0.1));
    private final NumberSetting breakRange  = addSetting(new NumberSetting("Break Range",  5.0, 1.0, 7.0, 0.1));
    private final NumberSetting minDmg      = addSetting(new NumberSetting("Min Damage",   6.0, 1.0, 20.0, 0.5));
    private final BooleanSetting antiSuicide= addSetting(new BooleanSetting("Anti Suicide", true));
    private final NumberSetting selfDmgMax  = addSetting(new NumberSetting("Max Self Dmg", 8.0, 0.0, 20.0, 0.5));
    private final NumberSetting delay       = addSetting(new NumberSetting("Delay (ms)",   50.0,0.0,500.0,10.0));

    private long lastAction = 0;

    public AutoCrystalModule() {
        super("AutoCrystal", "Places and breaks end crystals automatically.", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @SubscribeEvent
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.world == null) return;
        if (System.currentTimeMillis() - lastAction < delay.getValue()) return;

        // Find best target player
        PlayerEntity target = null;
        double closest = Double.MAX_VALUE;
        for (Entity ent : mc.world.getEntities()) {
            if (!(ent instanceof PlayerEntity p)) continue;
            if (p == mc.player) continue;
            double d = mc.player.distanceTo(p);
            if (d < closest && d <= placeRange.getValue() + 4) { closest = d; target = p; }
        }
        if (target == null) return;

        // Try to break existing crystals near target
        boolean broke = tryBreakCrystal(target);
        if (!broke) tryPlaceCrystal(target);
        lastAction = System.currentTimeMillis();
    }

    private boolean tryBreakCrystal(PlayerEntity target) {
        for (Entity ent : mc.world.getEntities()) {
            if (!(ent instanceof EndCrystalEntity crystal)) continue;
            if (mc.player.distanceTo(crystal) > breakRange.getValue()) continue;

            double dmg = calculateCrystalDamage(crystal.getPos(), target);
            if (dmg < minDmg.getValue()) continue;

            if (antiSuicide.isEnabled()) {
                double selfDmg = calculateCrystalDamage(crystal.getPos(), mc.player);
                if (selfDmg > selfDmgMax.getValue()) continue;
            }

            mc.player.attack(crystal);
            return true;
        }
        return false;
    }

    private void tryPlaceCrystal(PlayerEntity target) {
        if (!hasCrystals()) return;

        BlockPos best = null;
        double  bestScore = -1;

        // Scan blocks around target
        BlockPos targetPos = target.getBlockPos();
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                for (int y = -1; y <= 2; y++) {
                    BlockPos candidate = targetPos.add(x, y, z);
                    if (!isValidPlacement(candidate)) continue;
                    if (mc.player.distanceTo(Vec3d.ofCenter(candidate)) > placeRange.getValue()) continue;

                    Vec3d crystalPos = Vec3d.of(candidate).add(0.5, 1, 0.5);
                    double dmg = calculateCrystalDamage(crystalPos, target);
                    if (dmg < minDmg.getValue()) continue;

                    if (antiSuicide.isEnabled()) {
                        double selfDmg = calculateCrystalDamage(crystalPos, mc.player);
                        if (selfDmg > selfDmgMax.getValue()) continue;
                    }

                    if (dmg > bestScore) { bestScore = dmg; best = candidate; }
                }
            }
        }

        if (best == null) return;

        int prevSlot = mc.player.getInventory().selectedSlot;
        int crystalSlot = findCrystalSlot();
        if (crystalSlot == -1) return;
        mc.player.getInventory().selectedSlot = crystalSlot;

        BlockHitResult result = new BlockHitResult(
            Vec3d.ofCenter(best), Direction.UP, best, false
        );
        mc.player.networkHandler.sendPacket(
            net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket.of(
                Hand.MAIN_HAND, result, mc.player.networkHandler.sequenceNumber
            )
        );
        mc.player.getInventory().selectedSlot = prevSlot;
    }

    private boolean isValidPlacement(BlockPos pos) {
        if (mc.world == null) return false;
        var block = mc.world.getBlockState(pos).getBlock();
        if (block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) return false;
        var above = mc.world.getBlockState(pos.up());
        var above2 = mc.world.getBlockState(pos.up(2));
        return above.isAir() && above2.isAir();
    }

    private double calculateCrystalDamage(Vec3d crystalPos, PlayerEntity player) {
        // Simplified DPS calculation — real impl uses explosion damage formula
        double dist = crystalPos.distanceTo(player.getPos().add(0, player.getHeight() * 0.5, 0));
        double base = 12.0; // crystal base damage
        double dmg  = base * (1.0 - Math.min(dist / 12.0, 1.0));
        // Apply armor reduction (approximation)
        double armor = player.getArmor();
        dmg *= (1.0 - Math.min(armor / 25.0 * 0.75, 0.75));
        return dmg;
    }

    private boolean hasCrystals() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.END_CRYSTAL) return true;
        }
        return false;
    }

    private int findCrystalSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.END_CRYSTAL) return i;
        }
        return -1;
    }
}
