package phantom.modules.impl.movement;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;
public class StepModule extends Module {
    private final NumberSetting height=addSetting(new NumberSetting("Height",1.0,0.5,3.0,0.5));
    private float orig=0.6f;
    public StepModule(){super("Step","Step up blocks without jumping.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @Override public void onEnable(){ if(mc.player!=null){orig=mc.player.stepHeight; mc.player.stepHeight=(float)height.getValue();} }
    @Override public void onDisable(){ if(mc.player!=null) mc.player.stepHeight=orig; }
    @SubscribeEvent public void onTick(TickEvent e){ if(mc.player!=null) mc.player.stepHeight=(float)height.getValue(); }
}