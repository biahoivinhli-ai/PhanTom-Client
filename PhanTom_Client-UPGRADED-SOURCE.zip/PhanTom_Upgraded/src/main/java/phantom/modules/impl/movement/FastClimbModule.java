package phantom.modules.impl.movement;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;
public class FastClimbModule extends Module {
    private final NumberSetting speed=addSetting(new NumberSetting("Speed",0.3,0.1,1.0,0.05));
    public FastClimbModule(){super("FastClimb","Climb ladders faster.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){ if(mc.player!=null&&mc.player.isClimbing()) mc.player.setVelocity(mc.player.getVelocity().x,speed.getValue(),mc.player.getVelocity().z); }
}