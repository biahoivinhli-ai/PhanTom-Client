package phantom.modules.impl.combat;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;

public class AutoArmorModule extends Module {
    public AutoArmorModule(){super("AutoArmor","Automatically equips the best armor.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        for(int i=9;i<36;i++){
            var stack=mc.player.getInventory().getStack(i);
            if(!(stack.getItem() instanceof ArmorItem armor))continue;
            EquipmentSlot slot=armor.getSlotType();
            int armorSlotIndex=8-slot.getEntitySlotId();
            var current=mc.player.getInventory().getStack(armorSlotIndex);
            if(current.isEmpty()||(current.getItem() instanceof ArmorItem cur&&
               armor.getDefensePoints()>cur.getDefensePoints())){
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,i,0,SlotActionType.PICKUP,mc.player);
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,armorSlotIndex,0,SlotActionType.PICKUP,mc.player);
                if(!mc.player.playerScreenHandler.getCursorStack().isEmpty())
                    mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,i,0,SlotActionType.PICKUP,mc.player);
            }
        }
    }
}
