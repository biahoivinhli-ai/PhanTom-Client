package phantom.modules.impl.combat;

import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PickFromInventoryC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;

public class AutoTotemModule extends Module {
    private final NumberSetting hpThreshold = addSetting(new NumberSetting("HP Threshold",10.0,1.0,20.0,0.5));
    public AutoTotemModule(){super("AutoTotem","Auto holds totem in offhand.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        var offhand=mc.player.getOffHandStack();
        if(offhand.getItem()==Items.TOTEM_OF_UNDYING)return;
        if(mc.player.getHealth()>hpThreshold.getValue()&&offhand.getItem()!=Items.AIR)return;
        for(int i=9;i<36;i++){
            if(mc.player.getInventory().getStack(i).getItem()==Items.TOTEM_OF_UNDYING){
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,i,0,SlotActionType.PICKUP,mc.player);
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,45,0,SlotActionType.PICKUP,mc.player);
                if(!mc.player.playerScreenHandler.getCursorStack().isEmpty())
                    mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,i,0,SlotActionType.PICKUP,mc.player);
                break;
            }
        }
    }
}
