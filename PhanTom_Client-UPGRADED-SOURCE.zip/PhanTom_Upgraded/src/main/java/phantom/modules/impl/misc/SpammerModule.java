package phantom.modules.impl.misc;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;
import phantom.settings.impl.StringSetting;
public class SpammerModule extends Module {
    private final StringSetting message=addSetting(new StringSetting("Message","Phantom v1.0 | best client"));
    private final NumberSetting interval=addSetting(new NumberSetting("Interval (s)",5.0,1.0,60.0,1.0));
    private long last=0;
    public SpammerModule(){super("Spammer","Spams chat at an interval.",Module.Category.MISC,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        long now=System.currentTimeMillis();
        if(now-last>interval.getValue()*1000){
            mc.player.networkHandler.sendChatMessage(message.getValue());
            last=now;
        }
    }
}