package phantom.modules.impl.combat;

import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.NumberSetting;

/**
 * PhaseSurround – surround nâng cao hỗ trợ phase:
 * - Center + Floor + Extension
 * - AirPlace (đặt khi không có neighbor – hữu ích khi phase)
 * - Place nhanh khi đang ở trong block (phased)
 * Tham khảo logic Surround + Phase từ Night client.
 */
public class PhaseSurroundModule extends Module {

    private static final Direction[] HORIZ = {
        Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST
    };

    private final BooleanSetting center = addSetting(new BooleanSetting("Center", true));
    private final BooleanSetting floor = addSetting(new BooleanSetting("Floor", true));
    private final BooleanSetting airPlace = addSetting(new BooleanSetting("AirPlace", true));
    private final BooleanSetting onlyWhenPhased = addSetting(new BooleanSetting("OnlyWhenPhased", false));
    private final BooleanSetting rotate = addSetting(new BooleanSetting("Rotate", false));
    private final NumberSetting placeDelay = addSetting(new NumberSetting("PlaceDelay", 0, 0, 5, 1));

    private int delayCounter = 0;

    public PhaseSurroundModule() {
        super("PhaseSurround", "Advanced surround with phase/air-place support.", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @SubscribeEvent
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.world == null) return;

        boolean phased = isPhased();
        if (onlyWhenPhased.isEnabled() && !phased) return;

        if (delayCounter > 0) {
            delayCounter--;
            return;
        }

        if (center.isEnabled()) {
            double cx = Math.floor(mc.player.getX()) + 0.5;
            double cz = Math.floor(mc.player.getZ()) + 0.5;
            if (Math.abs(mc.player.getX() - cx) > 0.05 || Math.abs(mc.player.getZ() - cz) > 0.05) {
                mc.player.setPosition(cx, mc.player.getY(), cz);
            }
        }

        int obsSlot = findObsidian();
        if (obsSlot == -1) return;

        int prev = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = obsSlot;

        BlockPos feet = mc.player.getBlockPos();
        boolean placed = false;

        // 4 hướng ngang
        for (Direction d : HORIZ) {
            BlockPos target = feet.offset(d);
            if (canPlace(target)) {
                placeBlock(target, d.getOpposite());
                placed = true;
            }
            // extension: nếu bị block bởi entity thì đặt thêm 1 ô ra ngoài
            BlockPos ext = target.offset(d);
            if (airPlace.isEnabled() && canPlace(ext) && !mc.world.getBlockState(target).isAir()) {
                placeBlock(ext, d.getOpposite());
                placed = true;
            }
        }

        // Floor
        if (floor.isEnabled()) {
            BlockPos under = feet.down();
            if (canPlace(under)) {
                placeBlock(under, Direction.UP);
                placed = true;
            }
        }

        // Khi đang phase: ưu tiên đặt nhanh các ô xung quanh vị trí hiện tại
        if (phased && airPlace.isEnabled()) {
            for (Direction d : HORIZ) {
                BlockPos p = BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ()).offset(d);
                if (canPlace(p)) {
                    placeBlock(p, d.getOpposite());
                    placed = true;
                }
            }
        }

        mc.player.getInventory().selectedSlot = prev;
        if (placed) delayCounter = (int) placeDelay.getValue();
    }

    private boolean isPhased() {
        if (mc.player == null || mc.world == null) return false;
        BlockPos pos = mc.player.getBlockPos();
        return !mc.world.getBlockState(pos).isAir()
            || !mc.world.getBlockState(pos.up()).isAir();
    }

    private boolean canPlace(BlockPos pos) {
        if (mc.world == null) return false;
        if (!mc.world.getBlockState(pos).isAir() && !mc.world.getBlockState(pos).isReplaceable()) return false;
        if (!airPlace.isEnabled()) {
            // cần neighbor solid
            for (Direction d : Direction.values()) {
                if (!mc.world.getBlockState(pos.offset(d)).isAir()) return true;
            }
            return false;
        }
        return true;
    }

    private void placeBlock(BlockPos pos, Direction side) {
        BlockPos neighbor = pos.offset(side);
        Vec3d hit = Vec3d.ofCenter(neighbor).add(Vec3d.of(side.getVector()).multiply(0.5));
        BlockHitResult bhr = new BlockHitResult(hit, side.getOpposite(), neighbor, false);
        mc.player.networkHandler.sendPacket(
            PlayerInteractBlockC2SPacket.of(Hand.MAIN_HAND, bhr, mc.player.networkHandler.sequenceNumber)
        );
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private int findObsidian() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.OBSIDIAN) return i;
        }
        return -1;
    }
}
