package phantom.modules.impl.render;

import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.RenderOverlayEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.ModeSetting;
import phantom.Phantom;

import java.util.Comparator;
import java.util.List;

/**
 * PhanTom HUD – Neon Shader-style on-screen display.
 *
 * Module list styles:
 *   Default – simple right-side list (gradient glow per module)
 *   Array   – colored bracket array with animated width bars
 *   Minimal – tiny dots + names, no decoration
 *
 * Watermark – animated shimmer, dual-accent underline
 * FPS / Coords – styled info pills
 * PvP info – BPS and reach display (when in PvP)
 */
public class HUDModule extends Module {

    private static final int ACCENT_PRI = 0xFF9B59FF;
    private static final int ACCENT_SEC = 0xFF00E5FF;
    private static final int TEXT_MAIN  = 0xFFEEE8FF;
    private static final int TEXT_DIM   = 0xFF8888AA;

    private final BooleanSetting watermark = addSetting(new BooleanSetting("Watermark", true));
    private final BooleanSetting moduleList= addSetting(new BooleanSetting("Module List", true));
    private final BooleanSetting coords    = addSetting(new BooleanSetting("Coords", true));
    private final BooleanSetting fps       = addSetting(new BooleanSetting("FPS", true));
    private final BooleanSetting infoPills = addSetting(new BooleanSetting("Info Pills", true));
    private final ModeSetting style        = addSetting(new ModeSetting("Style", "Default",
            List.of("Default", "Array", "Minimal")));

    // Per-module width animation (Array style)
    private final java.util.Map<String, Float> barWidths = new java.util.HashMap<>();

    private float time = 0f;

    public HUDModule() {
        super("HUD", "Renders styled on-screen display.", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @SubscribeEvent
    public void onRender(RenderOverlayEvent e) {
        if (mc.player == null) return;
        DrawContext ctx = e.context;
        time += 0.016f; // ~60fps tick

        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        // ── Watermark ─────────────────────────────────────────────────────
        if (watermark.isEnabled()) renderWatermark(ctx);

        // ── Info pills ────────────────────────────────────────────────────
        if (infoPills.isEnabled()) renderInfoPills(ctx, sw, sh);

        // ── Module list ───────────────────────────────────────────────────
        if (moduleList.isEnabled()) {
            List<Module> enabled = Phantom.INSTANCE.moduleManager.getModules()
                    .stream()
                    .filter(m -> m.isEnabled() && m.isVisible())
                    .sorted(Comparator.comparingInt(m -> -mc.textRenderer.getWidth(m.getName())))
                    .toList();

            switch (style.getValue()) {
                case "Array"   -> renderArrayList(ctx, enabled, sw);
                case "Minimal" -> renderMinimalList(ctx, enabled, sw);
                default        -> renderDefaultList(ctx, enabled, sw);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  WATERMARK
    // ─────────────────────────────────────────────────────────────────────
    private void renderWatermark(DrawContext ctx) {
        String brand = "✦ PhanTom";
        String ver   = " v1.0";
        int bw = mc.textRenderer.getWidth(brand);
        int vw = mc.textRenderer.getWidth(ver);
        int totalW = bw + vw + 12;
        int x = 4, y = 4;

        // Background pill
        ctx.fill(x - 2, y - 2, x + totalW + 2, y + 12, 0xAA070715);
        ctx.fill(x - 2, y + 10, x + totalW + 2, y + 11, ACCENT_PRI);

        // Shimmer sweep across watermark
        float sw2 = (time * 0.6f) % 1.0f;
        int shimX = x + (int)(sw2 * totalW);
        ctx.fillGradient(shimX - 16, y - 2, shimX, y + 10, 0x00FFFFFF, 0x14FFFFFF);
        ctx.fillGradient(shimX, y - 2, shimX + 16, y + 10, 0x14FFFFFF, 0x00FFFFFF);

        // Text
        ctx.drawTextWithShadow(mc.textRenderer, brand, x + 4, y, ACCENT_PRI);
        ctx.drawTextWithShadow(mc.textRenderer, ver, x + 4 + bw, y, ACCENT_SEC);

        // Bottom dual-accent underline
        ctx.fillGradient(x - 2, y + 11, x + totalW / 2 + 2, y + 12, ACCENT_PRI, ACCENT_SEC);
        ctx.fillGradient(x + totalW / 2 + 2, y + 11, x + totalW + 2, y + 12, ACCENT_SEC, ACCENT_PRI);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INFO PILLS (FPS / Coords)
    // ─────────────────────────────────────────────────────────────────────
    private void renderInfoPills(DrawContext ctx, int sw, int sh) {
        int x = 4, y = 20;

        if (fps.isEnabled()) {
            String fpsStr = mc.fpsDebugString != null && !mc.fpsDebugString.isEmpty()
                    ? mc.fpsDebugString.split(" ")[0] : "??";
            String pill = "FPS " + fpsStr;
            int pw = mc.textRenderer.getWidth(pill) + 8;

            // FPS color: green if high, yellow if medium, red if low
            int fpsVal = parseFps(fpsStr);
            int pillCol = fpsVal >= 60 ? 0xFF39FF14 : (fpsVal >= 30 ? 0xFFFFCC00 : 0xFFFF3333);

            ctx.fill(x, y, x + pw, y + 11, 0xAA070715);
            ctx.fill(x, y + 10, x + pw, y + 11, pillCol);
            ctx.drawTextWithShadow(mc.textRenderer, pill, x + 4, y + 1, pillCol);
            y += 14;
        }

        if (coords.isEnabled() && mc.player != null) {
            double px = mc.player.getX(), py2 = mc.player.getY(), pz = mc.player.getZ();
            String xStr = String.format("§7X §f%.0f", px);
            String yStr = String.format(" §7Y §f%.0f", py2);
            String zStr = String.format(" §7Z §f%.0f", pz);
            // Strip § codes for width calc
            String raw = String.format("X %.0f  Y %.0f  Z %.0f", px, py2, pz);
            int pw = mc.textRenderer.getWidth(raw) + 12;

            ctx.fill(x, y, x + pw, y + 11, 0xAA070715);
            ctx.fill(x, y + 10, x + pw, y + 11, ACCENT_SEC);
            ctx.drawTextWithShadow(mc.textRenderer, xStr + yStr + zStr, x + 4, y + 1, TEXT_MAIN);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DEFAULT MODULE LIST
    // ─────────────────────────────────────────────────────────────────────
    private void renderDefaultList(DrawContext ctx, List<Module> enabled, int sw) {
        int rx = sw - 2;
        int ry = 2;
        for (Module m : enabled) {
            String name = m.getName();
            int nw = mc.textRenderer.getWidth(name);
            int x  = rx - nw - 4;

            // Glow background
            ctx.fillGradient(x - 4, ry - 1, rx, ry + 10,
                    0x00000000, 0x33000000);
            ctx.fill(x - 4, ry - 1, rx, ry + 10, 0x22000000);

            // Left dot
            float pulse = 0.6f + 0.4f * (float)Math.sin(time * 4f + ry * 0.1f);
            int dotCol = blend(ACCENT_PRI, ACCENT_SEC, (float)(ry % 80) / 80f);
            ctx.fill(x - 3, ry + 3, x - 1, ry + 7,
                    alphaScale(dotCol, pulse));

            // Right accent line
            ctx.fill(rx - 1, ry, rx, ry + 9,
                    alphaScale(dotCol, 0.7f));

            ctx.drawTextWithShadow(mc.textRenderer, name, x + 2, ry + 1, dotCol);
            ry += 11;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ARRAY MODULE LIST (with animated width bars)
    // ─────────────────────────────────────────────────────────────────────
    private void renderArrayList(DrawContext ctx, List<Module> enabled, int sw) {
        int rx = sw - 2;
        int ry = 2;
        for (Module m : enabled) {
            String name = m.getName();
            int nw = mc.textRenderer.getWidth(name);

            // Animated bar width
            float target = nw + 16f;
            float cur    = barWidths.getOrDefault(m.getName(), target);
            cur          = cur + (target - cur) * 0.18f;
            barWidths.put(m.getName(), cur);
            int bw = (int) cur;

            int x = rx - bw;

            // Background
            ctx.fill(x, ry, rx, ry + 11, 0xCC080818);
            // Left bracket
            ctx.fill(x, ry, x + 2, ry + 11, ACCENT_PRI);
            // Right bracket
            ctx.fill(rx - 2, ry, rx, ry + 11, ACCENT_SEC);
            // Bottom underline gradient
            ctx.fillGradient(x, ry + 10, rx, ry + 11, ACCENT_PRI, ACCENT_SEC);

            // Rainbow-ish color per position
            int col = blend(ACCENT_PRI, ACCENT_SEC, (float)(ry % 100) / 100f);
            ctx.drawTextWithShadow(mc.textRenderer, name, x + 5, ry + 2, col);

            ry += 13;
        }
        // Clean up removed modules
        barWidths.entrySet().removeIf(e ->
            enabled.stream().noneMatch(m -> m.getName().equals(e.getKey())));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MINIMAL MODULE LIST
    // ─────────────────────────────────────────────────────────────────────
    private void renderMinimalList(DrawContext ctx, List<Module> enabled, int sw) {
        int rx = sw - 2;
        int ry = 2;
        for (Module m : enabled) {
            String name = m.getName();
            int nw = mc.textRenderer.getWidth(name);
            int col = alphaScale(ACCENT_PRI, 0.8f + 0.2f * (float)Math.sin(time * 3f + ry));
            // Tiny dot
            ctx.fill(rx - nw - 7, ry + 4, rx - nw - 5, ry + 6, col);
            ctx.drawTextWithShadow(mc.textRenderer, name, rx - nw - 2, ry, TEXT_DIM);
            ry += 10;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UTILS
    // ─────────────────────────────────────────────────────────────────────
    private static int parseFps(String s) {
        try { return Integer.parseInt(s.replaceAll("[^0-9]", "")); }
        catch (Exception e) { return 0; }
    }

    private static int blend(int c1, int c2, float t) {
        int a = lerp((c1 >> 24) & 0xFF, (c2 >> 24) & 0xFF, t);
        int r = lerp((c1 >> 16) & 0xFF, (c2 >> 16) & 0xFF, t);
        int g = lerp((c1 >>  8) & 0xFF, (c2 >>  8) & 0xFF, t);
        int b = lerp( c1        & 0xFF,  c2        & 0xFF, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int alphaScale(int color, float f) {
        int a = (int)(((color >> 24) & 0xFF) * f) & 0xFF;
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private static int lerp(int a, int b, float t) {
        return (int)(a + (b - a) * t);
    }
}
