package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
public class NoRenderModule extends Module {
    private final BooleanSetting noPumpkin=addSetting(new BooleanSetting("No Pumpkin",true));
    private final BooleanSetting noFire=addSetting(new BooleanSetting("No Fire",true));
    private final BooleanSetting noWeather=addSetting(new BooleanSetting("No Weather",false));
    private final BooleanSetting noHurtcam=addSetting(new BooleanSetting("No Hurtcam",true));
    public NoRenderModule(){super("NoRender","Removes unwanted visual effects.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    public boolean isNoPumpkin(){ return isEnabled()&&noPumpkin.isEnabled(); }
    public boolean isNoFire(){ return isEnabled()&&noFire.isEnabled(); }
    public boolean isNoWeather(){ return isEnabled()&&noWeather.isEnabled(); }
    public boolean isNoHurtcam(){ return isEnabled()&&noHurtcam.isEnabled(); }
}