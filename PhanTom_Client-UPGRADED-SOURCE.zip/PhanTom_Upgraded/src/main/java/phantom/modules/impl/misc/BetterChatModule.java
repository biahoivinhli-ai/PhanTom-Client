package phantom.modules.impl.misc;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
public class BetterChatModule extends Module {
    private final BooleanSetting timestamps=addSetting(new BooleanSetting("Timestamps",true));
    private final BooleanSetting infiniteHistory=addSetting(new BooleanSetting("Infinite History",true));
    public BetterChatModule(){super("BetterChat","Enhances chat functionality.",Module.Category.MISC,GLFW.GLFW_KEY_UNKNOWN);}
    public boolean showTimestamps(){ return isEnabled()&&timestamps.isEnabled(); }
    public boolean infiniteHistory(){ return isEnabled()&&infiniteHistory.isEnabled(); }
}