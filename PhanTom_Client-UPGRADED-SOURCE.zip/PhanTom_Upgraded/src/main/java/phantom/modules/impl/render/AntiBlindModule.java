package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import net.minecraft.entity.effect.StatusEffects;
public class AntiBlindModule extends Module {
    public AntiBlindModule(){super("AntiBlind","Removes blindness and darkness effects.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        mc.player.removeStatusEffect(StatusEffects.BLINDNESS);
        mc.player.removeStatusEffect(StatusEffects.DARKNESS);
    }
}