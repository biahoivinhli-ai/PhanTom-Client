package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
public class TracersModule extends Module {
    private final BooleanSetting players=addSetting(new BooleanSetting("Players",true));
    private final BooleanSetting mobs=addSetting(new BooleanSetting("Mobs",false));
    public TracersModule(){super("Tracers","Draws lines to entities.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
}