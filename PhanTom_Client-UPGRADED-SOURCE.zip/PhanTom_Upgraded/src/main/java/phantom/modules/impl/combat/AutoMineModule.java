package phantom.modules.impl.combat;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;

public class AutoMineModule extends Module {
    private final NumberSetting range=addSetting(new NumberSetting("Range",4.0,1.0,6.0,0.1));
    public AutoMineModule(){super("AutoMine","Automatically mines blocks around enemies.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null||mc.world==null)return;
        for(var ent:mc.world.getEntities()){
            if(!(ent instanceof PlayerEntity p)||p==mc.player)continue;
            if(mc.player.distanceTo(p)>range.getValue())continue;
            BlockPos target=p.getBlockPos();
            for(BlockPos bp:new BlockPos[]{target,target.north(),target.south(),target.east(),target.west()}){
                if(mc.world.getBlockState(bp).isAir())continue;
                mc.interactionManager.attackBlock(bp,net.minecraft.util.math.Direction.UP);
                break;
            }
        }
    }
}
