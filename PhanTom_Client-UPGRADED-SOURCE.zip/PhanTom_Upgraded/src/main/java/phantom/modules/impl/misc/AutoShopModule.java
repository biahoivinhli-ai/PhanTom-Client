package phantom.modules.impl.misc;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.NumberSetting;
import phantom.settings.impl.StringSetting;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * AutoShop – tự động mở /shop và mua item (Totem, Crystal, Pearl, Gapple, Obsidian, Exp, Arrow).
 * Logic tham khảo Night AutoShopModule_Upgraded (slot layout + state machine).
 */
public class AutoShopModule extends Module {

    // Shop GUI slots (server layout)
    private static final int SLOT_TOTEM     = 11;
    private static final int SLOT_CRYSTAL   = 13;
    private static final int SLOT_EXP       = 15;
    private static final int SLOT_OBSIDIAN  = 29;
    private static final int SLOT_PEARL     = 31;
    private static final int SLOT_GAPPLE    = 33;
    private static final int SLOT_ARROW     = 35;
    private static final int SLOT_SET_1     = 48;
    private static final int SLOT_SET_11    = 50;
    private static final int SLOT_CONFIRM   = 49;

    private enum State { IDLE, WAIT_SHOP, CLICK_ITEM, SET_QTY, CONFIRM }
    private enum ShopItem { TOTEM, CRYSTAL, EXP, OBSIDIAN, PEARL, GAPPLE, ARROW }

    private State state = State.IDLE;
    private ShopItem currentItem = null;
    private int ticks = 0;
    private int cooldown = 0;
    private final Queue<ShopItem> queue = new ArrayDeque<>();

    private final StringSetting shopCmd = addSetting(new StringSetting("ShopCommand", "shop open gear"));
    private final BooleanSetting autoRestock = addSetting(new BooleanSetting("AutoRestock", true));
    private final NumberSetting minTotem = addSetting(new NumberSetting("MinTotem", 1, 0, 64, 1));
    private final NumberSetting minCrystal = addSetting(new NumberSetting("MinCrystal", 64, 0, 512, 1));
    private final NumberSetting minPearl = addSetting(new NumberSetting("MinPearl", 16, 0, 256, 1));
    private final NumberSetting minGapple = addSetting(new NumberSetting("MinGapple", 16, 0, 256, 1));
    private final NumberSetting minObsidian = addSetting(new NumberSetting("MinObsidian", 64, 0, 512, 1));
    private final NumberSetting minExp = addSetting(new NumberSetting("MinExp", 64, 0, 512, 1));
    private final NumberSetting delay = addSetting(new NumberSetting("ClickDelay", 3, 1, 20, 1));

    public AutoShopModule() {
        super("AutoShop", "Auto buy from server /shop GUI (totem, crystal, pearl...).", Category.MISC, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onDisable() {
        reset();
    }

    private void reset() {
        state = State.IDLE;
        currentItem = null;
        ticks = 0;
        queue.clear();
    }

    @SubscribeEvent
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.world == null) return;
        if (cooldown > 0) { cooldown--; return; }

        if (autoRestock.isEnabled() && state == State.IDLE) {
            checkAndEnqueue();
        }

        switch (state) {
            case IDLE -> {
                if (!queue.isEmpty()) {
                    currentItem = queue.poll();
                    openShop();
                    state = State.WAIT_SHOP;
                    ticks = 0;
                }
            }
            case WAIT_SHOP -> {
                ticks++;
                if (isShopOpen()) {
                    state = State.CLICK_ITEM;
                    ticks = 0;
                } else if (ticks > 40) {
                    reset();
                    cooldown = 20;
                }
            }
            case CLICK_ITEM -> {
                ticks++;
                if (ticks < delay.getValue()) return;
                clickSlot(getSlot(currentItem));
                state = State.SET_QTY;
                ticks = 0;
            }
            case SET_QTY -> {
                ticks++;
                if (ticks < delay.getValue()) return;
                // click set 11 (or set 1) then confirm
                clickSlot(SLOT_SET_11);
                state = State.CONFIRM;
                ticks = 0;
            }
            case CONFIRM -> {
                ticks++;
                if (ticks < delay.getValue()) return;
                clickSlot(SLOT_CONFIRM);
                // close
                if (mc.player != null) mc.player.closeHandledScreen();
                state = State.IDLE;
                currentItem = null;
                ticks = 0;
                cooldown = 10;
            }
        }
    }

    private void checkAndEnqueue() {
        if (count(Items.TOTEM_OF_UNDYING) < minTotem.getValue()) queue.offer(ShopItem.TOTEM);
        if (count(Items.END_CRYSTAL) < minCrystal.getValue()) queue.offer(ShopItem.CRYSTAL);
        if (count(Items.ENDER_PEARL) < minPearl.getValue()) queue.offer(ShopItem.PEARL);
        if (count(Items.GOLDEN_APPLE) + count(Items.ENCHANTED_GOLDEN_APPLE) < minGapple.getValue()) queue.offer(ShopItem.GAPPLE);
        if (count(Items.OBSIDIAN) < minObsidian.getValue()) queue.offer(ShopItem.OBSIDIAN);
        if (count(Items.EXPERIENCE_BOTTLE) < minExp.getValue()) queue.offer(ShopItem.EXP);
        if (count(Items.ARROW) < 64) queue.offer(ShopItem.ARROW);
    }

    private int count(Item item) {
        int c = 0;
        for (int i = 0; i < 36; i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.getItem() == item) c += s.getCount();
        }
        return c;
    }

    private void openShop() {
        String cmd = shopCmd.getValue().trim();
        if (!cmd.startsWith("/")) cmd = "/" + cmd;
        mc.player.networkHandler.sendChatCommand(cmd.substring(1));
    }

    private boolean isShopOpen() {
        return mc.currentScreen instanceof HandledScreen && !(mc.currentScreen instanceof InventoryScreen);
    }

    private int getSlot(ShopItem item) {
        return switch (item) {
            case TOTEM -> SLOT_TOTEM;
            case CRYSTAL -> SLOT_CRYSTAL;
            case EXP -> SLOT_EXP;
            case OBSIDIAN -> SLOT_OBSIDIAN;
            case PEARL -> SLOT_PEARL;
            case GAPPLE -> SLOT_GAPPLE;
            case ARROW -> SLOT_ARROW;
        };
    }

    private void clickSlot(int slot) {
        if (mc.player == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof HandledScreen<?> screen)) return;
        int syncId = screen.getScreenHandler().syncId;
        mc.interactionManager.clickSlot(syncId, slot, 0, SlotActionType.PICKUP, mc.player);
    }
}
