package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
public class StorageESPModule extends Module {
    public StorageESPModule(){super("StorageESP","Shows chests, furnaces, etc.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
}