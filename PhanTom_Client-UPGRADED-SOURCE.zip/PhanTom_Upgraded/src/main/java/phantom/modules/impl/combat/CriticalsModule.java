package phantom.modules.impl.combat;

import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.AttackEntityEvent;
import phantom.modules.Module;
import phantom.settings.impl.ModeSetting;
import java.util.List;

public class CriticalsModule extends Module {
    private final ModeSetting mode = addSetting(new ModeSetting("Mode","Packet",List.of("Packet","Jump","MiniJump")));
    public CriticalsModule(){super("Criticals","Forces critical hits on every attack.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onAttack(AttackEntityEvent e){
        if(mc.player==null)return;
        switch(mode.getValue()){
            case"Packet"->{
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),mc.player.getY()+0.0625,mc.player.getZ(),false,mc.player.horizontalCollision));
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),mc.player.getY(),mc.player.getZ(),false,mc.player.horizontalCollision));
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),mc.player.getY()+1.1E-5,mc.player.getZ(),false,mc.player.horizontalCollision));
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),mc.player.getY(),mc.player.getZ(),false,mc.player.horizontalCollision));
            }
            case"Jump"->{mc.player.jump();}
            case"MiniJump"->{mc.player.setVelocity(mc.player.getVelocity().x,0.2,mc.player.getVelocity().z);}
        }
    }
}
