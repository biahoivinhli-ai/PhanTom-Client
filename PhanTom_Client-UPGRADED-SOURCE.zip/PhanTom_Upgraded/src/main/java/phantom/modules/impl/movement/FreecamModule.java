package phantom.modules.impl.movement;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;
public class FreecamModule extends Module {
    private final NumberSetting speed=addSetting(new NumberSetting("Speed",0.5,0.1,3.0,0.1));
    private Vec3d savedPos;
    public FreecamModule(){super("Freecam","Detach camera from player.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @Override public void onEnable(){ if(mc.player!=null) savedPos=mc.player.getPos(); }
    @Override public void onDisable(){ if(mc.player!=null&&savedPos!=null) mc.player.setPosition(savedPos.x,savedPos.y,savedPos.z); }
    @SubscribeEvent
    public void onTick(TickEvent e){ if(mc.player!=null){mc.player.setVelocity(Vec3d.ZERO);mc.player.fallDistance=0;} }
}