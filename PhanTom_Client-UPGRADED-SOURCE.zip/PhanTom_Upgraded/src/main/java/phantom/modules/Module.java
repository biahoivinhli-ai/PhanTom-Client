package phantom.modules;

import net.minecraft.client.MinecraftClient;
import phantom.Phantom;
import phantom.settings.Setting;
import phantom.events.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;

public abstract class Module {

    public enum Category {
        COMBAT("Combat"),
        MOVEMENT("Movement"),
        RENDER("Render"),
        MISC("Misc");

        public final String name;
        Category(String name) { this.name = name; }
        @Override public String toString() { return name; }
    }

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String   name;
    private final String   description;
    private final Category category;
    private       int      keybind;
    private       boolean  enabled;
    private       boolean  visible = true;

    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category, int keybind) {
        this.name        = name;
        this.description = description;
        this.category    = category;
        this.keybind     = keybind;
    }

    protected <T extends Setting<?>> T addSetting(T setting) {
        settings.add(setting);
        return setting;
    }

    // --- lifecycle ---

    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean state) {
        if (this.enabled == state) return;
        this.enabled = state;
        if (state) {
            Phantom.INSTANCE.eventHandler.register(this);
            onEnable();
        } else {
            Phantom.INSTANCE.eventHandler.unregister(this);
            onDisable();
        }
    }

    // --- getters ---
    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public int      getKeybind()     { return keybind; }
    public boolean  isEnabled()      { return enabled; }
    public boolean  isVisible()      { return visible; }
    public List<Setting<?>> getSettings() { return settings; }
    public void setKeybind(int k)    { keybind = k; }
    public void setVisible(boolean v){ visible = v; }
}
