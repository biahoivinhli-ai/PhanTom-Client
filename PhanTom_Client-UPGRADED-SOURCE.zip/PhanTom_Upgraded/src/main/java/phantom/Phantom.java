package phantom;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import phantom.managers.ModuleManager;
import phantom.managers.ConfigManager;
import phantom.managers.HudManager;
import phantom.events.EventHandler;
import phantom.utils.font.FontRenderer;
import phantom.gui.ClickGuiScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Phantom implements ClientModInitializer {

    public static final String NAME    = "Phantom";
    public static final String VERSION = "v1.0";
    public static final Logger LOG     = LoggerFactory.getLogger("phantom");

    public static Phantom INSTANCE;
    public static MinecraftClient mc;

    public ModuleManager moduleManager;
    public ConfigManager  configManager;
    public HudManager     hudManager;
    public EventHandler   eventHandler;
    public FontRenderer   fontRenderer;
    public ClickGuiScreen clickGui;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        mc       = MinecraftClient.getInstance();

        LOG.info("[Phantom] Booting " + NAME + " " + VERSION);

        eventHandler   = new EventHandler();
        moduleManager  = new ModuleManager();
        hudManager     = new HudManager();
        configManager  = new ConfigManager();
        fontRenderer   = new FontRenderer("JetBrainsMono", 18);
        clickGui       = new ClickGuiScreen();

        moduleManager.init();
        hudManager.init();
        configManager.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            eventHandler.dispatchTick();
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (mc.player == null) return;
            eventHandler.dispatchRenderOverlay(drawContext, tickDelta);
            hudManager.render(drawContext, tickDelta);
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> configManager.save());

        LOG.info("[Phantom] Ready.");
    }
}
