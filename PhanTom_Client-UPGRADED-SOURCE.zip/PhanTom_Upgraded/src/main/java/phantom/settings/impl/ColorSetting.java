package phantom.settings.impl;
import phantom.settings.Setting;

public class ColorSetting extends Setting<Integer> {
    private float alpha;

    public ColorSetting(String name, int defaultColor) {
        super(name, defaultColor);
        this.alpha = 1.0f;
    }

    public int getColor()    { return value; }
    public float getAlpha()  { return alpha; }
    public void setAlpha(float a) { alpha = a; }
    public int getRed()      { return (value >> 16) & 0xFF; }
    public int getGreen()    { return (value >>  8) & 0xFF; }
    public int getBlue()     { return value & 0xFF; }

    @Override public String getValueString() {
        return String.format("#%06X", value & 0xFFFFFF);
    }
}
