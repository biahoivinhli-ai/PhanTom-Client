package phantom.settings.impl;
import phantom.settings.Setting;

public class NumberSetting extends Setting<Double> {
    private final double min, max, step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, defaultValue);
        this.min  = min;
        this.max  = max;
        this.step = step;
    }

    @Override
    public void setValue(Double value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public double getMin()  { return min; }
    public double getMax()  { return max; }
    public double getStep() { return step; }

    @Override public String getValueString() {
        return String.format("%.2f", value);
    }
}
