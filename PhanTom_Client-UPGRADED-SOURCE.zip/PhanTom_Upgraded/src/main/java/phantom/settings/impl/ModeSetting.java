package phantom.settings.impl;
import phantom.settings.Setting;
import java.util.List;

public class ModeSetting extends Setting<String> {
    private final List<String> options;

    public ModeSetting(String name, String defaultValue, List<String> options) {
        super(name, defaultValue);
        this.options = options;
    }

    public List<String> getOptions() { return options; }

    public void cycle() {
        int idx = options.indexOf(value);
        value = options.get((idx + 1) % options.size());
    }

    @Override public String getValueString() { return value; }
}
