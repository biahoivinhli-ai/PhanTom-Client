package phantom.settings.impl;
import phantom.settings.Setting;
import org.lwjgl.glfw.GLFW;

public class BindSetting extends Setting<Integer> {
    public BindSetting(String name, int defaultKey) {
        super(name, defaultKey);
    }
    @Override public String getValueString() {
        return value == GLFW.GLFW_KEY_UNKNOWN ? "None" : GLFW.glfwGetKeyName(value, 0);
    }
}
