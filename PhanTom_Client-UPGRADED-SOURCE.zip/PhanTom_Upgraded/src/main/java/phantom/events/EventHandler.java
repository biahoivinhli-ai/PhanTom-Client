package phantom.events;

import net.minecraft.client.gui.DrawContext;
import phantom.events.impl.*;
import phantom.modules.Module;
import phantom.Phantom;

import java.lang.reflect.Method;
import java.util.*;

public class EventHandler {

    private final Map<Class<?>, List<SubscriberEntry>> subscribers = new HashMap<>();

    public void register(Object obj) {
        for (Method m : obj.getClass().getDeclaredMethods()) {
            if (!m.isAnnotationPresent(SubscribeEvent.class)) continue;
            if (m.getParameterCount() != 1) continue;
            Class<?> evType = m.getParameterTypes()[0];
            m.setAccessible(true);
            subscribers.computeIfAbsent(evType, k -> new ArrayList<>())
                       .add(new SubscriberEntry(obj, m));
        }
    }

    public void unregister(Object obj) {
        for (List<SubscriberEntry> list : subscribers.values()) {
            list.removeIf(e -> e.owner == obj);
        }
    }

    public <T> T dispatch(T event) {
        List<SubscriberEntry> list = subscribers.get(event.getClass());
        if (list == null) return event;
        for (SubscriberEntry e : list) {
            try { e.method.invoke(e.owner, event); }
            catch (Exception ex) { ex.printStackTrace(); }
        }
        return event;
    }

    // --- convenience dispatchers called from mixins / tick ---

    public void dispatchTick() {
        dispatch(new TickEvent());
    }

    public void dispatchTickPost() {
        dispatch(new TickEvent.Post());
    }

    public void dispatchRenderOverlay(DrawContext ctx, float delta) {
        dispatch(new RenderOverlayEvent(ctx, delta));
    }

    public PacketSendEvent dispatchPacketSend(Object packet) {
        return dispatch(new PacketSendEvent(packet));
    }

    public PacketSendEvent.Post dispatchPacketSendPost(Object packet) {
        return dispatch(new PacketSendEvent.Post(packet));
    }

    public UpdateVelocityEvent dispatchUpdateVelocity(double x, double y, double z) {
        return dispatch(new UpdateVelocityEvent(x, y, z));
    }

    public AttackEntityEvent dispatchAttackEntity(Object target) {
        return dispatch(new AttackEntityEvent(target));
    }

    public ClientRotationEvent dispatchRotation(float yaw, float pitch) {
        return dispatch(new ClientRotationEvent(yaw, pitch));
    }

    public EventInput dispatchInput(boolean forward, boolean back, boolean left, boolean right,
                                    boolean jump, boolean sneak, boolean sprint) {
        return dispatch(new EventInput(forward, back, left, right, jump, sneak, sprint));
    }

    public PlayerUpdateEvent dispatchPlayerUpdate() {
        return dispatch(new PlayerUpdateEvent());
    }

    public PlayerUpdateEvent.Post dispatchPlayerUpdatePost() {
        return dispatch(new PlayerUpdateEvent.Post());
    }

    public RenderWorldEvent dispatchRenderWorld(Object matrices, float delta) {
        return dispatch(new RenderWorldEvent(matrices, delta));
    }

    public RenderWorldEvent.Post dispatchRenderWorldPost(Object matrices, float delta) {
        return dispatch(new RenderWorldEvent.Post(matrices, delta));
    }

    private record SubscriberEntry(Object owner, Method method) {}
}
