package phantom.events.impl;
import net.minecraft.entity.player.PlayerEntity;
public class PlayerPopEvent {
    public final PlayerEntity player;
    public PlayerPopEvent(PlayerEntity player) { this.player = player; }
}
