package phantom.events.impl;

public class TickEvent {
    private boolean cancelled;
    public boolean isCancelled() { return cancelled; }
    public void cancel() { cancelled = true; }

    public static class Post extends TickEvent {}
}
