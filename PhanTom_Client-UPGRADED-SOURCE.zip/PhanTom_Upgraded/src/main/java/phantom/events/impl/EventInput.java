package phantom.events.impl;
public class EventInput {
    public boolean forward, back, left, right, jump, sneak, sprint;
    public EventInput(boolean forward, boolean back, boolean left, boolean right,
                      boolean jump, boolean sneak, boolean sprint) {
        this.forward = forward; this.back = back; this.left = left; this.right = right;
        this.jump = jump; this.sneak = sneak; this.sprint = sprint;
    }
}
