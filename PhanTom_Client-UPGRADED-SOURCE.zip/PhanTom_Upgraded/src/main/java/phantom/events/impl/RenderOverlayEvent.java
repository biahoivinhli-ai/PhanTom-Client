package phantom.events.impl;
import net.minecraft.client.gui.DrawContext;
public class RenderOverlayEvent {
    public final DrawContext context;
    public final float delta;
    public RenderOverlayEvent(DrawContext context, float delta) { this.context = context; this.delta = delta; }
}
