package phantom.events.impl;
public class PlayerUpdateEvent {
    public static class Post extends PlayerUpdateEvent {}
}
