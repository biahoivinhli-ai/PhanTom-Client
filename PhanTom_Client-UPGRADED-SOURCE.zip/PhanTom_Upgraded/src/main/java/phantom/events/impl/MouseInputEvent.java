package phantom.events.impl;
public class MouseInputEvent {
    public final int button, action, mods;
    public MouseInputEvent(int button, int action, int mods) { this.button = button; this.action = action; this.mods = mods; }
}
