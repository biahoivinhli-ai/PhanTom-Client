# PhanTom Client – Build Instructions

## Requirements
- Java 25+ (Adoptium / Eclipse Temurin recommended)  
- Internet connection (Gradle pulls Fabric dependencies on first build)

## Build
```bash
# Linux / macOS
chmod +x gradlew
./gradlew build

# Windows
gradlew.bat build
```

Output: `build/libs/PhanTom_Client-1.0.0.jar`

## Install
Copy the jar into your Fabric mods folder:
- **Windows**: `%AppData%\.minecraft\mods\`  
- **macOS**: `~/Library/Application Support/minecraft/mods/`  
- **Linux**: `~/.minecraft/mods/`

Requires: Fabric Loader 0.16.14+, Fabric API 0.153.0+26.1.2, MC 26.1.2

## What's New in This Build

### ClickGUI (Right Shift)
- **Glassmorphism panels** – layered frosted-glass depth
- **Animated gradient headers** – per-category color scheme (combat=purple, movement=navy, render=teal, misc=amber)
- **Shimmer sweep** – scrolling highlight across panel headers
- **Neon enabled bars** – chromatic R/G fringe on active indicator
- **Smooth hover fade** – per-module hover brightness animation
- **Status dot** – green dot (enabled) / dim dot (disabled)
- **Settings panel** – toggle pill UI for booleans, animated slider for numbers
- **Module count badge** – live `enabled/total` in header corner
- **Neon cursor dot** – pulsing cyan crosshair

### Shaders (`assets/phantom/shaders/program/`)
#### `menu_glow.fsh` (post-process on GUI screen)
- Chromatic aberration – RGB channel split at screen edges
- CRT scanline grid – fine horizontal + vertical micro-lines
- Vignette – smooth black edge fade
- Neon edge bloom – pulsing purple sides + cyan top
- Film grain – time-varying hash noise
- Light leak sweep – slow diagonal bright streak

#### `panel_blur.fsh` (new – frosted glass backdrop)
- 9-tap Gaussian blur behind GUI panels
- Purple tint + top-lighter frosted gradient

### TitleScreen
- Particle rain – 60 falling dots (purple/cyan/white) with trails
- Dual scan-line sweeps (white ghost + neon purple)
- Animated glow blobs behind vanilla content
- Corner tech brackets
- Shimmer watermark branding

### HUD (Module)
- **Default** – gradient colored dots + right accent line per module
- **Array** – animated-width brackets with purple→cyan gradient, animated bar expand/contract
- **Minimal** – dots only, very subtle
- Info pills: FPS (green/yellow/red based on value), XYZ coords
- Watermark shimmer sweep + dual-accent underline
